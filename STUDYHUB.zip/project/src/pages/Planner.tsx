import { useState, useMemo } from 'react';
import { Plus, BookOpen, Target, Clock, Sparkles, Trash2, Calendar, AlertTriangle, CheckCircle, Lightbulb } from 'lucide-react';
import { useSubjects } from '@/hooks/useSubjects';
import { useAssignments } from '@/hooks/useAssignments';
import { useStudySessions } from '@/hooks/useStudySessions';
import { useToast } from '@/context/ToastContext';
import { Card, Button, EmptyState, Loader, StatCard } from '@/components/ui';
import { Modal } from '@/components/Modal';
import { formatMinutes, getDaysUntilDue, cn } from '@/lib/helpers';
import { format, parseISO, subDays } from 'date-fns';

const colorOptions = ['#6366f1', '#8b5cf6', '#06b6d4', '#f59e0b', '#10b981', '#ef4444', '#ec4899', '#14b8a6'];

interface StudyBlock {
  subject: string;
  color: string;
  duration: number;
  assignment?: string;
  type: 'study' | 'assignment';
  day: string;
}

export function Planner() {
  const { subjects, createSubject, deleteSubject, loading: loadingSubjects } = useSubjects();
  const { assignments } = useAssignments();
  const { sessions } = useStudySessions();
  const { showToast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [availableTime, setAvailableTime] = useState(180);
  const [generatedPlan, setGeneratedPlan] = useState<StudyBlock[] | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [newSubject, setNewSubject] = useState({ name: '', color: colorOptions[0], goal_hours_per_week: 5 });
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const subjectStats = useMemo(() => {
    return subjects.map((s) => {
      const sessionMinutes = sessions
        .filter((sess) => sess.subject_id === s.id)
        .filter((sess) => {
          const days = Math.floor((Date.now() - new Date(sess.completed_at).getTime()) / (1000 * 60 * 60 * 24));
          return days <= 7;
        })
        .reduce((sum, sess) => sum + sess.duration_minutes, 0);
      const goalMinutes = s.goal_hours_per_week * 60;
      const progress = goalMinutes > 0 ? Math.min(100, Math.round((sessionMinutes / goalMinutes) * 100)) : 0;
      return { ...s, sessionMinutes, goalMinutes, progress };
    });
  }, [subjects, sessions]);

  const pendingAssignments = useMemo(() => {
    return assignments
      .filter((a) => a.status === 'pending')
      .sort((a, b) => {
        const aDays = getDaysUntilDue(a.due_date) ?? 999;
        const bDays = getDaysUntilDue(b.due_date) ?? 999;
        if (aDays !== bDays) return aDays - bDays;
        const priorityWeight = { high: 0, medium: 1, low: 2 };
        return priorityWeight[a.priority] - priorityWeight[b.priority];
      });
  }, [assignments]);

  const generatePlan = () => {
    if (subjects.length === 0) {
      showToast('Add subjects first to generate a plan', 'error');
      return;
    }

    const totalAvailable = availableTime;
    const plan: StudyBlock[] = [];
    let remainingTime = totalAvailable;
    const today = format(new Date(), 'EEE');

    // Priority 1: Urgent assignments (due within 3 days)
    const urgent = pendingAssignments.filter((a) => {
      const days = getDaysUntilDue(a.due_date);
      return days !== null && days <= 3;
    });

    urgent.forEach((a) => {
      if (remainingTime < 25) return;
      const blockTime = Math.min(50, remainingTime);
      const subj = subjects.find((s) => s.id === a.subject_id);
      plan.push({
        subject: subj?.name || 'General',
        color: subj?.color || '#8b5cf6',
        duration: blockTime,
        assignment: a.title,
        type: 'assignment',
        day: today,
      });
      remainingTime -= blockTime;
    });

    // Priority 2: Subjects behind their weekly goal
    const behindSubjects = subjectStats
      .filter((s) => s.progress < 100)
      .sort((a, b) => a.progress - b.progress);

    for (const s of behindSubjects) {
      if (remainingTime < 25) break;
      const deficit = s.goalMinutes - s.sessionMinutes;
      const blockTime = Math.min(Math.min(deficit, 50), remainingTime);
      if (blockTime < 25) continue;
      plan.push({
        subject: s.name,
        color: s.color,
        duration: blockTime,
        type: 'study',
        day: today,
      });
      remainingTime -= blockTime;
    }

    // Priority 3: Remaining time to highest priority pending assignments
    for (const a of pendingAssignments) {
      if (remainingTime < 25) break;
      if (urgent.includes(a)) continue;
      const blockTime = Math.min(25, remainingTime);
      const subj = subjects.find((s) => s.id === a.subject_id);
      plan.push({
        subject: subj?.name || 'General',
        color: subj?.color || '#8b5cf6',
        duration: blockTime,
        assignment: a.title,
        type: 'assignment',
        day: today,
      });
      remainingTime -= blockTime;
    }

    setGeneratedPlan(plan);
    showToast(`Study plan generated for ${formatMinutes(totalAvailable - remainingTime)}`);
  };

  const handleCreateSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.name.trim()) {
      showToast('Please enter a subject name', 'error');
      return;
    }
    setSubmitting(true);
    try {
      await createSubject({
        name: newSubject.name.trim(),
        color: newSubject.color,
        goal_hours_per_week: newSubject.goal_hours_per_week,
      });
      showToast('Subject added successfully');
      setNewSubject({ name: '', color: colorOptions[0], goal_hours_per_week: 5 });
      setModalOpen(false);
    } catch {
      showToast('Failed to add subject', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteSubject = async (id: string) => {
    try {
      await deleteSubject(id);
      showToast('Subject deleted');
      setConfirmDelete(null);
    } catch {
      showToast('Failed to delete subject', 'error');
    }
  };

  if (loadingSubjects) return <Loader label="Loading planner..." />;

  return (
    <div className="space-y-6 animate-[fadeIn_0.4s_ease-out]">
      {/* Top Section: Generate Plan */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/20 to-indigo-500/10 text-violet-500">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Generate Study Schedule</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">AI-powered study plan based on your priorities</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
                Available study time today: <span className="text-violet-500">{formatMinutes(availableTime)}</span>
              </label>
              <input
                type="range"
                min="30"
                max="480"
                step="15"
                value={availableTime}
                onChange={(e) => { setAvailableTime(Number(e.target.value)); setGeneratedPlan(null); }}
                className="w-full accent-violet-500"
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>30m</span>
                <span>2h</span>
                <span>4h</span>
                <span>8h</span>
              </div>
            </div>

            <Button onClick={generatePlan} size="lg" className="w-full">
              <Sparkles className="h-5 w-5" /> Generate Study Plan
            </Button>
          </div>
        </Card>

        <div className="space-y-4">
          <StatCard icon={<BookOpen className="h-5 w-5" />} label="Subjects" value={subjects.length} color="violet" />
          <StatCard icon={<Target className="h-5 w-5" />} label="Weekly Goal" value={formatMinutes(subjectStats.reduce((s, sub) => s + sub.goalMinutes, 0))} color="indigo" />
          <StatCard icon={<AlertTriangle className="h-5 w-5" />} label="Urgent Tasks" value={pendingAssignments.filter((a) => { const d = getDaysUntilDue(a.due_date); return d !== null && d <= 3; }).length} color="rose" />
        </div>
      </div>

      {/* Generated Plan */}
      {generatedPlan && (
        <Card className="p-6 animate-[slideUp_0.4s_ease-out]">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500/20 to-emerald-500/5 text-emerald-500">
                <CheckCircle className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Your Suggested Study Plan</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">{formatMinutes(generatedPlan.reduce((s, b) => s + b.duration, 0))} of study time allocated</p>
              </div>
            </div>
            <Button variant="secondary" size="sm" onClick={() => setGeneratedPlan(null)}>Clear</Button>
          </div>

          {generatedPlan.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400 py-4 text-center">No study blocks generated. Try increasing your available time.</p>
          ) : (
            <div className="space-y-3">
              {generatedPlan.map((block, i) => (
                <div key={i} className="flex items-center gap-4 rounded-xl border border-slate-200/60 dark:border-white/5 p-4 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl font-display text-sm font-bold text-white" style={{ backgroundColor: block.color }}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{block.subject}</span>
                      <span className={cn(
                        'text-xs font-semibold px-2 py-0.5 rounded-md',
                        block.type === 'assignment' ? 'bg-amber-500/10 text-amber-500' : 'bg-sky-500/10 text-sky-500'
                      )}>
                        {block.type === 'assignment' ? 'Assignment' : 'Study'}
                      </span>
                    </div>
                    {block.assignment && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{block.assignment}</p>}
                  </div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-600 dark:text-slate-300">
                    <Clock className="h-4 w-4 text-slate-400" />
                    {formatMinutes(block.duration)}
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="mt-4 rounded-xl bg-violet-500/5 border border-violet-500/10 p-4 flex gap-3">
            <Lightbulb className="h-5 w-5 text-violet-500 shrink-0 mt-0.5" />
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Start with the first block now. Use Focus Mode for each session, and check off assignments as you complete them.
            </p>
          </div>
        </Card>
      )}

      {/* Subjects Management */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Your Subjects</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Manage subjects and weekly study goals</p>
          </div>
          <Button onClick={() => setModalOpen(true)} size="sm">
            <Plus className="h-4 w-4" /> Add Subject
          </Button>
        </div>

        {subjects.length === 0 ? (
          <Card className="p-6">
            <EmptyState
              icon={<BookOpen className="h-7 w-7" />}
              title="No subjects yet"
              description="Add your subjects to start planning your study schedule."
              action={<Button onClick={() => setModalOpen(true)}><Plus className="h-4 w-4" /> Add Subject</Button>}
            />
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {subjectStats.map((s) => (
              <Card key={s.id} hover className="p-5 group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl" style={{ backgroundColor: s.color }} />
                    <div>
                      <h4 className="font-display font-semibold text-slate-900 dark:text-white">{s.name}</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{formatMinutes(s.goalMinutes)} / week</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setConfirmDelete(s.id)}
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 opacity-0 group-hover:opacity-100 hover:bg-red-500/10 hover:text-red-500 transition-all"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-500 dark:text-slate-400">This week</span>
                    <span className="font-semibold text-slate-600 dark:text-slate-300">{formatMinutes(s.sessionMinutes)} / {formatMinutes(s.goalMinutes)}</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${s.progress}%`, backgroundColor: s.color }}
                    />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Add Subject Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Add Subject">
        <form onSubmit={handleCreateSubject} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Subject Name</label>
            <input
              type="text"
              value={newSubject.name}
              onChange={(e) => setNewSubject({ ...newSubject, name: e.target.value })}
              placeholder="e.g. Biology"
              className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
              autoFocus
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Color</label>
            <div className="flex gap-2 flex-wrap">
              {colorOptions.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setNewSubject({ ...newSubject, color: c })}
                  className={cn(
                    'h-9 w-9 rounded-xl transition-all',
                    newSubject.color === c ? 'ring-2 ring-offset-2 ring-violet-500 dark:ring-offset-slate-900 scale-110' : 'hover:scale-105'
                  )}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
              Weekly study goal: <span className="text-violet-500">{newSubject.goal_hours_per_week}h</span>
            </label>
            <input
              type="range"
              min="1"
              max="20"
              step="1"
              value={newSubject.goal_hours_per_week}
              onChange={(e) => setNewSubject({ ...newSubject, goal_hours_per_week: Number(e.target.value) })}
              className="w-full accent-violet-500"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <Button type="submit" disabled={submitting} className="flex-1">
              {submitting ? 'Adding...' : 'Add Subject'}
            </Button>
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
          </div>
        </form>
      </Modal>

      {/* Delete Subject Confirmation */}
      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Delete Subject" className="max-w-md">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-300">Are you sure you want to delete this subject? Assignments linked to it will remain but lose their subject association.</p>
          <div className="flex gap-3">
            <Button variant="danger" onClick={() => confirmDelete && handleDeleteSubject(confirmDelete)} className="flex-1">
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
            <Button variant="secondary" onClick={() => setConfirmDelete(null)}>Cancel</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
