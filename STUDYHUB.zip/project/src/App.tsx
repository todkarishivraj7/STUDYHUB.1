import { useState } from 'react';
import { ThemeProvider } from '@/context/ThemeContext';
import { ToastProvider } from '@/context/ToastContext';
import { Sidebar, type PageId } from '@/components/Sidebar';
import { TopBar } from '@/components/TopBar';
import { Dashboard } from '@/pages/Dashboard';
import { Assignments } from '@/pages/Assignments';
import { Planner } from '@/pages/Planner';
import { FocusMode } from '@/pages/FocusMode';
import { Analytics } from '@/pages/Analytics';
import { Assistant } from '@/pages/Assistant';
import { Settings } from '@/pages/Settings';

const pageMeta: Record<PageId, { title: string; subtitle: string }> = {
  dashboard: { title: 'Dashboard', subtitle: 'Your study overview at a glance' },
  assignments: { title: 'Assignments', subtitle: 'Manage your tasks and deadlines' },
  planner: { title: 'Smart Study Planner', subtitle: 'AI-powered study schedule generation' },
  focus: { title: 'Focus Mode', subtitle: 'Pomodoro timer for deep work sessions' },
  analytics: { title: 'Analytics', subtitle: 'Track your study progress and productivity' },
  assistant: { title: 'AI Study Assistant', subtitle: 'Get personalized study recommendations' },
  settings: { title: 'Settings', subtitle: 'Customize your experience' },
};

function AppContent() {
  const [activePage, setActivePage] = useState<PageId>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const handleNavigate = (page: PageId) => {
    setActivePage(page);
    setMobileSidebarOpen(false);
  };

  const meta = pageMeta[activePage];

  return (
    <div className="app-bg min-h-screen">
      <Sidebar
        activePage={activePage}
        onNavigate={handleNavigate}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />
      <div className="md:ml-72">
        <TopBar
          title={meta.title}
          subtitle={meta.subtitle}
          onMenuClick={() => setMobileSidebarOpen(true)}
        />
        <main className="p-4 md:p-8 max-w-[1600px] mx-auto">
          {activePage === 'dashboard' && <Dashboard onNavigate={handleNavigate} />}
          {activePage === 'assignments' && <Assignments />}
          {activePage === 'planner' && <Planner />}
          {activePage === 'focus' && <FocusMode />}
          {activePage === 'analytics' && <Analytics />}
          {activePage === 'assistant' && <Assistant />}
          {activePage === 'settings' && <Settings />}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </ThemeProvider>
  );
}
