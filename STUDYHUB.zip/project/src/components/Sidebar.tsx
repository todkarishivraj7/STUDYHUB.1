import { GraduationCap, LayoutDashboard, BookOpen, CheckSquare, Timer, BarChart3, Bot, Settings, X } from 'lucide-react';
import { cn } from '@/lib/helpers';

export type PageId = 'dashboard' | 'assignments' | 'planner' | 'focus' | 'analytics' | 'assistant' | 'settings';

interface NavItem {
  id: PageId;
  label: string;
  icon: typeof LayoutDashboard;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'assignments', label: 'Assignments', icon: CheckSquare },
  { id: 'planner', label: 'Study Planner', icon: BookOpen },
  { id: 'focus', label: 'Focus Mode', icon: Timer },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'assistant', label: 'AI Assistant', icon: Bot },
  { id: 'settings', label: 'Settings', icon: Settings },
];

interface SidebarProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export function Sidebar({ activePage, onNavigate, mobileOpen, onCloseMobile }: SidebarProps) {
  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm md:hidden"
          onClick={onCloseMobile}
        />
      )}
      <aside
        className={cn(
          'fixed left-0 top-0 z-40 flex h-screen w-72 flex-col border-r border-slate-200/60 dark:border-white/5 transition-transform duration-300',
          'bg-white/80 dark:bg-[#0c1033]/90 backdrop-blur-2xl',
          mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        )}
      >
        <div className="flex items-center justify-between px-6 py-6">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 shadow-lg shadow-violet-500/30">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
              <div className="absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full bg-emerald-400 ring-2 ring-white dark:ring-[#0c1033]" />
            </div>
            <div>
              <h1 className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white">STUDYHUB</h1>
              <p className="text-xs font-medium text-violet-500 dark:text-violet-400">AI Powered</p>
            </div>
          </div>
          <button onClick={onCloseMobile} className="md:hidden text-slate-500 hover:text-slate-900 dark:hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1.5 px-3 py-2 scrollbar-thin overflow-y-auto">
          <p className="px-3 pb-2 pt-3 text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">Menu</p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={cn(
                  'group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200',
                  isActive
                    ? 'bg-gradient-to-r from-violet-500/15 to-indigo-500/10 text-violet-600 dark:text-violet-300'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-white/5 dark:hover:text-slate-200'
                )}
              >
                <span className={cn(
                  'flex h-8 w-8 items-center justify-center rounded-lg transition-all',
                  isActive
                    ? 'bg-gradient-to-br from-violet-500 to-indigo-600 text-white shadow-md shadow-violet-500/25'
                    : 'bg-slate-100 text-slate-500 group-hover:bg-slate-200 dark:bg-white/5 dark:text-slate-400 dark:group-hover:bg-white/10'
                )}>
                  <Icon className="h-4 w-4" />
                </span>
                {item.label}
                {isActive && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-violet-500" />}
              </button>
            );
          })}
        </nav>

        <div className="p-4">
          <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-indigo-500/10 p-4 border border-violet-500/10">
            <div className="flex items-center gap-2 mb-2">
              <Bot className="h-4 w-4 text-violet-500" />
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">AI Assistant</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">Get personalized study recommendations and tips.</p>
            <button
              onClick={() => onNavigate('assistant')}
              className="text-xs font-semibold text-violet-600 dark:text-violet-400 hover:text-violet-700 dark:hover:text-violet-300 transition-colors"
            >
              Ask a question →
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
