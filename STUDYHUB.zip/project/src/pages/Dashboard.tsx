import { useMemo } from 'react';
import {
  CheckSquare, Clock, Calendar, AlertTriangle, BookOpen, TrendingUp, Flame, ArrowRight, Plus, Timer,
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadialBarChart, RadialBar,
} from 'recharts';
import { useAssignments } from '@/hooks/useAssignments';
import { useSubjects } from '@/hooks/useSubjects';
import { useStudySessions } from '@/hooks/useStudySessions';
import { useTheme } from '@/context/ThemeContext';
import { Card, StatCard, EmptyState, Loader } from '@/components/ui';
import { formatMinutes, formatDueDate, getDaysUntilDue, getPriorityColor, cn } from '@/lib/helpers';
import { format, subDays, parseISO, isToday } from 'date-fns';
import type { PageId } from '@/components/Sidebar';

export function Dashboard({ onNavigate }: { onNavigate: (page: PageId) => void }) {
  const { assignments, loading: loadingAssignments } = useAssignments();
  const { subjects } = useSubjects();
  const { sessions } = useStudySessions();
  const { prefs } = useTheme();

  const stats = useMemo(() => {
    const total = assignments.length;
    const completed = assignments.filter((a) => a.status === 'completed').length;
    const pending = total - completed;
    const overdue = assignments.filter((a) => {
      if (a.status === 'completed' || !a.due_date) return false;
      return (getDaysUntilDue(a.due_date) ?? 0) < 0;
    }).length;
    const totalStudyMinutes = sessions.reduce((sum, s) => sum + s.duration_minutes, 0);
    const todayMinutes = sessions.filter((s) => isToday(parseISO(s.completed_at))).reduce((sum, s) => sum + s.duration_minutes, 0);
    return { total, completed, pending, overdue, totalStudyMinutes, todayMinutes };
  }, [assignments, sessions]);

  const weeklyData = useMemo(() => {
    const days: { day: string; minutes: number; label: string }[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dayLabel = format(date, 'EEE');
      const dateStr = format(date, 'yyyy-MM-dd');
      const minutes = sessions
        .filter((s) => format(parseISO(s.completed_at), 'yyyy-MM-dd') === dateStr)
        .reduce((sum, s) => sum + s.duration_minutes, 0);
      days.push({ day: dayLabel, minutes, label: format(date, 'MMM d') });
    }
    return days;
  }, [sessions]);

  const upcomingAssignments = useMemo(() => {
    return assignments
      .filter((a) => a.status === 'pending' && a.due_date)
      .sort((a, b) => (a.due_date || '').localeCompare(b.due_date || ''))
      .slice(0, 5);
  }, [assignments]);

  const todaySchedule = useMemo(() => {
    const today = format(new Date(), 'yyyy-MM-dd');
    const todaySessions = sessions.filter((s) => format(parseISO(s.completed_at), 'yyyy-MM-dd') === today);
    const upcoming = assignments
      .filter((a) => a.status === 'pending' && a.due_date && format(parseISO(a.due_date), 'yyyy-MM-dd') === today)
      .sort((a, b) => (a.due_date || '').localeCompare(b.due_date || ''));
    return { sessions: todaySessions, assignments: upcoming };
  }, [sessions, assignments]);

  const completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;

  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }, []);

  if (loadingAssignments && assignments.length === 0) {
    return <Loader label="Loading your dashboard..." />;
  }

  return (
    <div className="space-y-6 animate-[fadeIn_0.4s_ease-out]">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600 via-indigo-600 to-navy-700 p-6 md:p-8 text-white shadow-xl shadow-violet-500/20">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -right-20 top-20 h-32 w-32 rounded-full bg-violet-400/20 blur-3xl" />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-violet-200">{greeting},</p>
            <h2 className="font-display text-2xl md:text-3xl font-bold mt-1">{prefs?.student_name}!</h2>
            <p className="text-sm text-violet-100 mt-2 max-w-md">
              {stats.pending > 0
                ? `You have ${stats.pending} pending ${stats.pending === 1 ? 'assignment' : 'assignments'}${stats.overdue > 0 ? ` and ${stats.overdue} overdue` : ''}. Stay focused!`
                : 'All caught up! Great work on completing your assignments.'}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onNavigate('focus')}
              className="flex items-center gap-2 rounded-xl bg-white/15 px-4 py-2.5 text-sm font-semibold backdrop-blur-sm hover:bg-white/25 transition-all"
            >
              <Timer className="h-4 w-4" /> Start Focus
            </button>
            <button
              onClick={() => onNavigate('planner')}
              className="flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-violet-700 hover:bg-violet-50 transition-all"
            >
              <Plus className="h-4 w-4" /> Plan Study
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard icon={<CheckSquare className="h-5 w-5" />} label="Total Assignments" value={stats.total} color="violet" />
        <StatCard icon={<CheckSquare className="h-5 w-5" />} label="Completed" value={stats.completed} color="emerald" trend={`${completionRate}%`} trendUp />
        <StatCard icon={<Clock className="h-5 w-5" />} label="Pending" value={stats.pending} color="amber" />
        <StatCard icon={<AlertTriangle className="h-5 w-5" />} label="Overdue" value={stats.overdue} color="rose" />
        <StatCard icon={<Flame className="h-5 w-5" />} label="Today's Focus" value={formatMinutes(stats.todayMinutes)} color="sky" />
        <StatCard icon={<BookOpen className="h-5 w-5" />} label="Total Study" value={formatMinutes(stats.totalStudyMinutes)} color="indigo" />
      </div>

      {/* Charts and Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Productivity Chart */}
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Weekly Productivity</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Study hours over the past 7 days</p>
            </div>
            <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
              <TrendingUp className="h-4 w-4 text-emerald-500" />
              <span className="font-semibold text-slate-700 dark:text-slate-200">{formatMinutes(weeklyData.reduce((s, d) => s + d.minutes, 0))}</span>
              this week
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={weeklyData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="studyGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.1)" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}m`} />
              <Tooltip
                contentStyle={{
                  background: 'rgba(15,23,42,0.95)',
                  border: '1px solid rgba(139,92,246,0.3)',
                  borderRadius: '12px',
                  color: '#e2e8f0',
                  fontSize: '13px',
                }}
                labelStyle={{ color: '#a78bfa' }}
                formatter={(value) => [formatMinutes(Number(value)), 'Study Time']}
              />
              <Area type="monotone" dataKey="minutes" stroke="#8b5cf6" strokeWidth={2.5} fill="url(#studyGradient)" dot={{ fill: '#8b5cf6', r: 4 }} activeDot={{ r: 6 }} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Completion Rate */}
        <Card className="p-6">
          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-1">Completion Rate</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Task progress overview</p>
          <div className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={180}>
              <RadialBarChart innerRadius="65%" outerRadius="100%" data={[{ value: completionRate, fill: '#8b5cf6' }]} startAngle={90} endAngle={-270}>
                <RadialBar background={{ fill: 'rgba(148,163,184,0.1)' }} dataKey="value" cornerRadius={20} />
                <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" fill="#8b5cf6" fontSize="32" fontWeight="700" fontFamily="Sora">
                  {completionRate}%
                </text>
              </RadialBarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 text-center">
            <div className="rounded-xl bg-emerald-500/10 p-3">
              <p className="text-xl font-bold text-emerald-500">{stats.completed}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Completed</p>
            </div>
            <div className="rounded-xl bg-amber-500/10 p-3">
              <p className="text-xl font-bold text-amber-500">{stats.pending}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Pending</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Upcoming Deadlines & Today's Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Deadlines */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Upcoming Deadlines</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Next assignments due</p>
            </div>
            <button
              onClick={() => onNavigate('assignments')}
              className="text-sm font-semibold text-violet-600 dark:text-violet-400 hover:text-violet-700 dark:hover:text-violet-300 flex items-center gap-1 transition-colors"
            >
              View all <ArrowRight className="h-4 w-4" />
            </button>
          </div>
          {upcomingAssignments.length === 0 ? (
            <EmptyState
              icon={<Calendar className="h-7 w-7" />}
              title="No upcoming deadlines"
              description="You're all caught up! Add new assignments to see them here."
              action={<button onClick={() => onNavigate('assignments')} className="text-sm font-semibold text-violet-600 dark:text-violet-400">Go to Assignments →</button>}
            />
          ) : (
            <div className="space-y-3">
              {upcomingAssignments.map((a) => {
                const daysLeft = getDaysUntilDue(a.due_date);
                const pc = getPriorityColor(a.priority);
                return (
                  <div key={a.id} className="flex items-center gap-3 rounded-xl border border-slate-200/60 dark:border-white/5 p-3 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                    <div className={cn('flex h-10 w-10 items-center justify-center rounded-xl font-display text-xs font-bold', pc.bg, pc.text)}>
                      {formatDueDate(a.due_date).split(' ')[0]?.slice(0, 3) || '—'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 truncate">{a.title}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{a.subject?.name || 'No subject'}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className={cn('text-xs font-semibold px-2 py-0.5 rounded-md', pc.bg, pc.text)}>{formatDueDate(a.due_date)}</span>
                      {daysLeft !== null && daysLeft >= 0 && (
                        <span className="text-[10px] text-slate-400">{daysLeft === 0 ? 'Due today' : `${daysLeft}d left`}</span>
                      )}
                      {daysLeft !== null && daysLeft < 0 && (
                        <span className="text-[10px] text-red-500">{Math.abs(daysLeft)}d overdue</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Today's Schedule */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Today's Schedule</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Focus sessions & due tasks</p>
            </div>
            <button
              onClick={() => onNavigate('focus')}
              className="text-sm font-semibold text-violet-600 dark:text-violet-400 hover:text-violet-700 dark:hover:text-violet-300 flex items-center gap-1 transition-colors"
            >
              Focus <Timer className="h-4 w-4" />
            </button>
          </div>
          {todaySchedule.sessions.length === 0 && todaySchedule.assignments.length === 0 ? (
            <EmptyState
              icon={<Clock className="h-7 w-7" />}
              title="Nothing scheduled today"
              description="Start a focus session or add assignments to build your schedule."
              action={<button onClick={() => onNavigate('focus')} className="text-sm font-semibold text-violet-600 dark:text-violet-400">Start Focus Session →</button>}
            />
          ) : (
            <div className="space-y-3">
              {todaySchedule.assignments.map((a) => (
                <div key={`a-${a.id}`} className="flex items-center gap-3 rounded-xl bg-amber-500/5 border border-amber-500/10 p-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/10 text-amber-500">
                    <AlertTriangle className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 truncate">{a.title}</p>
                    <p className="text-xs text-amber-600 dark:text-amber-400">Due today</p>
                  </div>
                </div>
              ))}
              {todaySchedule.sessions.map((s) => (
                <div key={`s-${s.id}`} className="flex items-center gap-3 rounded-xl bg-emerald-500/5 border border-emerald-500/10 p-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-500">
                    <Timer className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{s.subject?.name || 'General Study'}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{formatMinutes(s.duration_minutes)} focus session</p>
                  </div>
                  <span className="text-xs text-emerald-500 font-semibold">Done</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
