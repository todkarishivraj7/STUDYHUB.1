/*
# STUDYHUB AI - Core Database Schema

1. New Tables
- `subjects` — academic subjects with study goals and time allocations
  - id (uuid, PK), name (text), color (text), goal_hours_per_week (numeric), created_at
- `assignments` — assignments with due dates, priorities, and completion status
  - id (uuid, PK), title, description, subject_id (FK), due_date, priority (text), status (text), created_at, updated_at
- `study_sessions` — completed focus/study sessions
  - id (uuid, PK), subject_id (FK nullable), duration_minutes (int), session_type (text), completed_at
- `user_preferences` — single-row settings table for theme and study preferences
  - id (uuid, PK), theme (text), daily_study_goal (int), pomodoro_focus (int), pomodoro_break (int), student_name (text)

2. Security
- Single-tenant app (no auth). RLS enabled on all tables.
- Policies allow anon + authenticated full CRUD on all tables (data is intentionally shared).

3. Notes
- No user_id columns or auth dependencies — this is a single-user demo app.
- user_preferences is designed to hold a single row.
*/

CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  color text NOT NULL DEFAULT '#8b5cf6',
  goal_hours_per_week numeric NOT NULL DEFAULT 5,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_subjects" ON subjects;
CREATE POLICY "anon_select_subjects" ON subjects FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_subjects" ON subjects;
CREATE POLICY "anon_insert_subjects" ON subjects FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_subjects" ON subjects;
CREATE POLICY "anon_update_subjects" ON subjects FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_subjects" ON subjects;
CREATE POLICY "anon_delete_subjects" ON subjects FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text DEFAULT '',
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  due_date date,
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_assignments" ON assignments;
CREATE POLICY "anon_select_assignments" ON assignments FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_assignments" ON assignments;
CREATE POLICY "anon_insert_assignments" ON assignments FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_assignments" ON assignments;
CREATE POLICY "anon_update_assignments" ON assignments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_assignments" ON assignments;
CREATE POLICY "anon_delete_assignments" ON assignments FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid REFERENCES subjects(id) ON DELETE SET NULL,
  duration_minutes int NOT NULL DEFAULT 25,
  session_type text NOT NULL DEFAULT 'pomodoro',
  completed_at timestamptz DEFAULT now()
);

ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_sessions" ON study_sessions;
CREATE POLICY "anon_select_sessions" ON study_sessions FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_sessions" ON study_sessions;
CREATE POLICY "anon_insert_sessions" ON study_sessions FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_sessions" ON study_sessions;
CREATE POLICY "anon_update_sessions" ON study_sessions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_sessions" ON study_sessions;
CREATE POLICY "anon_delete_sessions" ON study_sessions FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  theme text NOT NULL DEFAULT 'dark',
  daily_study_goal int NOT NULL DEFAULT 120,
  pomodoro_focus int NOT NULL DEFAULT 25,
  pomodoro_break int NOT NULL DEFAULT 5,
  student_name text NOT NULL DEFAULT 'Student',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_prefs" ON user_preferences;
CREATE POLICY "anon_select_prefs" ON user_preferences FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_prefs" ON user_preferences;
CREATE POLICY "anon_insert_prefs" ON user_preferences FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_prefs" ON user_preferences;
CREATE POLICY "anon_update_prefs" ON user_preferences FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_prefs" ON user_preferences;
CREATE POLICY "anon_delete_prefs" ON user_preferences FOR DELETE TO anon, authenticated USING (true);
