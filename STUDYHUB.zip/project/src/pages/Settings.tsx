import { Sun, Moon, User, Clock, Target, Save } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/context/ToastContext';
import { Card, Button } from '@/components/ui';
import { cn } from '@/lib/helpers';
import { useState } from 'react';

export function Settings() {
  const { theme, toggleTheme, prefs, updatePrefs } = useTheme();
  const { showToast } = useToast();
  const [name, setName] = useState(prefs?.student_name || '');
  const [dailyGoal, setDailyGoal] = useState(prefs?.daily_study_goal || 120);
  const [focusLen, setFocusLen] = useState(prefs?.pomodoro_focus || 25);
  const [breakLen, setBreakLen] = useState(prefs?.pomodoro_break || 5);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await updatePrefs({
        student_name: name.trim() || 'Student',
        daily_study_goal: dailyGoal,
        pomodoro_focus: focusLen,
        pomodoro_break: breakLen,
      });
      showToast('Settings saved successfully');
    } catch {
      showToast('Failed to save settings', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 animate-[fadeIn_0.4s_ease-out] max-w-3xl">
      {/* Profile */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/20 to-indigo-500/10 text-violet-500">
            <User className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Profile</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Your display name and preferences</p>
          </div>
        </div>
        <div>
          <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">Display Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
          />
        </div>
      </Card>

      {/* Appearance */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/20 to-indigo-500/10 text-violet-500">
            {theme === 'dark' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </div>
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Appearance</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Choose your theme</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => theme !== 'light' && toggleTheme()}
            className={cn(
              'flex items-center gap-3 rounded-xl border-2 p-4 transition-all',
              theme === 'light'
                ? 'border-violet-500 bg-violet-500/5'
                : 'border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20'
            )}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-100 text-amber-600">
              <Sun className="h-5 w-5" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Light Mode</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Bright and clean</p>
            </div>
          </button>
          <button
            onClick={() => theme !== 'dark' && toggleTheme()}
            className={cn(
              'flex items-center gap-3 rounded-xl border-2 p-4 transition-all',
              theme === 'dark'
                ? 'border-violet-500 bg-violet-500/5'
                : 'border-slate-200 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20'
            )}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-800 text-violet-400">
              <Moon className="h-5 w-5" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">Dark Mode</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Easy on the eyes</p>
            </div>
          </button>
        </div>
      </Card>

      {/* Study Goals */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/20 to-indigo-500/10 text-violet-500">
            <Target className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Study Goals</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Set your daily study target</p>
          </div>
        </div>
        <div>
          <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
            Daily Study Goal: <span className="text-violet-500">{Math.floor(dailyGoal / 60)}h {dailyGoal % 60}m</span>
          </label>
          <input
            type="range"
            min="30"
            max="480"
            step="15"
            value={dailyGoal}
            onChange={(e) => setDailyGoal(Number(e.target.value))}
            className="w-full accent-violet-500"
          />
        </div>
      </Card>

      {/* Pomodoro Settings */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/20 to-indigo-500/10 text-violet-500">
            <Clock className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Pomodoro Timer</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Customize your focus sessions</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
              Focus Duration: <span className="text-violet-500">{focusLen} min</span>
            </label>
            <input
              type="range"
              min="10"
              max="60"
              step="5"
              value={focusLen}
              onChange={(e) => setFocusLen(Number(e.target.value))}
              className="w-full accent-violet-500"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2">
              Break Duration: <span className="text-violet-500">{breakLen} min</span>
            </label>
            <input
              type="range"
              min="3"
              max="20"
              step="1"
              value={breakLen}
              onChange={(e) => setBreakLen(Number(e.target.value))}
              className="w-full accent-violet-500"
            />
          </div>
        </div>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving} size="lg">
          <Save className="h-5 w-5" /> {saving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
}
