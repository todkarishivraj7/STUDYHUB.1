import { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, RotateCcw, Coffee, Brain, Check, Flame, Clock, BookOpen } from 'lucide-react';
import { useStudySessions } from '@/hooks/useStudySessions';
import { useSubjects } from '@/hooks/useSubjects';
import { useTheme } from '@/context/ThemeContext';
import { useToast } from '@/context/ToastContext';
import { Card, Button, EmptyState, Loader, StatCard } from '@/components/ui';
import { formatMinutes, cn } from '@/lib/helpers';
import { format, parseISO, isToday } from 'date-fns';

type TimerMode = 'focus' | 'break';
type TimerState = 'idle' | 'running' | 'paused';

export function FocusMode() {
  const { sessions, createSession, loading } = useStudySessions();
  const { subjects } = useSubjects();
  const { prefs } = useTheme();
  const { showToast } = useToast();

  const focusDuration = prefs?.pomodoro_focus ?? 25;
  const breakDuration = prefs?.pomodoro_break ?? 5;

  const [mode, setMode] = useState<TimerMode>('focus');
  const [state, setState] = useState<TimerState>('idle');
  const [secondsLeft, setSecondsLeft] = useState(focusDuration * 60);
  const [selectedSubject, setSelectedSubject] = useState<string>('');
  const [completedCount, setCompletedCount] = useState(0);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Reset timer when durations change
  useEffect(() => {
    if (state === 'idle') {
      setSecondsLeft((mode === 'focus' ? focusDuration : breakDuration) * 60);
    }
  }, [focusDuration, breakDuration, mode, state]);

  const handleComplete = useCallback(async () => {
    if (mode === 'focus') {
      try {
        await createSession(selectedSubject || null, focusDuration, 'pomodoro');
        setCompletedCount((c) => c + 1);
        showToast('Focus session complete! Time for a break.', 'success');
      } catch {
        showToast('Session completed but failed to save', 'error');
      }
      setMode('break');
      setSecondsLeft(breakDuration * 60);
      setState('running');
    } else {
      showToast('Break over! Ready for another focus session?', 'info');
      setMode('focus');
      setSecondsLeft(focusDuration * 60);
      setState('idle');
    }
  }, [mode, focusDuration, breakDuration, selectedSubject, createSession, showToast]);

  // Timer tick
  useEffect(() => {
    if (state === 'running') {
      intervalRef.current = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            if (intervalRef.current) clearInterval(intervalRef.current);
            handleComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [state, handleComplete]);

  const handleStart = () => {
    setState('running');
  };

  const handlePause = () => {
    setState('paused');
  };

  const handleReset = () => {
    setState('idle');
    setMode('focus');
    setSecondsLeft(focusDuration * 60);
  };

  const handleModeSwitch = (newMode: TimerMode) => {
    if (state === 'running') return;
    setMode(newMode);
    setSecondsLeft((newMode === 'focus' ? focusDuration : breakDuration) * 60);
    setState('idle');
  };

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const timeStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const totalSeconds = (mode === 'focus' ? focusDuration : breakDuration) * 60;
  const progress = ((totalSeconds - secondsLeft) / totalSeconds) * 100;

  const todaySessions = sessions.filter((s) => isToday(parseISO(s.completed_at)));
  const todayMinutes = todaySessions.reduce((sum, s) => sum + s.duration_minutes, 0);

  const circumference = 2 * Math.PI * 140;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  if (loading) return <Loader label="Loading focus mode..." />;

  return (
    <div className="space-y-6 animate-[fadeIn_0.4s_ease-out]">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timer */}
        <Card className="lg:col-span-2 p-8 flex flex-col items-center">
          {/* Mode Switcher */}
          <div className="flex gap-2 rounded-2xl bg-slate-100 dark:bg-white/5 p-1.5 mb-8">
            <button
              onClick={() => handleModeSwitch('focus')}
              disabled={state === 'running'}
              className={cn(
                'flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-semibold transition-all',
                mode === 'focus'
                  ? 'bg-gradient-to-r from-violet-500 to-indigo-600 text-white shadow-lg shadow-violet-500/25'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              )}
            >
              <Brain className="h-4 w-4" /> Focus
            </button>
            <button
              onClick={() => handleModeSwitch('break')}
              disabled={state === 'running'}
              className={cn(
                'flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-semibold transition-all',
                mode === 'break'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              )}
            >
              <Coffee className="h-4 w-4" /> Break
            </button>
          </div>

          {/* Circular Timer */}
          <div className="relative w-[320px] h-[320px] flex items-center justify-center">
            <svg className="absolute inset-0 -rotate-90" width="320" height="320">
              <circle
                cx="160" cy="160" r="140"
                fill="none"
                stroke="rgba(148,163,184,0.1)"
                strokeWidth="12"
              />
              <circle
                cx="160" cy="160" r="140"
                fill="none"
                stroke={mode === 'focus' ? '#8b5cf6' : '#10b981'}
                strokeWidth="12"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-1000 ease-linear"
                style={{ filter: `drop-shadow(0 0 8px ${mode === 'focus' ? 'rgba(139,92,246,0.5)' : 'rgba(16,185,129,0.5)'})` }}
              />
            </svg>
            <div className="flex flex-col items-center">
              <div className={cn(
                'flex h-14 w-14 items-center justify-center rounded-2xl mb-3',
                mode === 'focus' ? 'bg-violet-500/10 text-violet-500' : 'bg-emerald-500/10 text-emerald-500'
              )}>
                {mode === 'focus' ? <Brain className="h-7 w-7" /> : <Coffee className="h-7 w-7" />}
              </div>
              <div className="font-display text-5xl font-bold tabular-nums text-slate-900 dark:text-white">
                {timeStr}
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                {state === 'idle' && (mode === 'focus' ? 'Ready to focus?' : 'Time to relax')}
                {state === 'running' && (mode === 'focus' ? 'Stay focused!' : 'Enjoy your break')}
                {state === 'paused' && 'Paused'}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-3 mt-8">
            {state === 'idle' || state === 'paused' ? (
              <Button onClick={handleStart} size="lg" className="min-w-[140px]">
                <Play className="h-5 w-5" /> {state === 'paused' ? 'Resume' : 'Start'}
              </Button>
            ) : (
              <Button onClick={handlePause} size="lg" variant="secondary" className="min-w-[140px]">
                <Pause className="h-5 w-5" /> Pause
              </Button>
            )}
            <Button onClick={handleReset} size="lg" variant="ghost">
              <RotateCcw className="h-5 w-5" /> Reset
            </Button>
          </div>

          {/* Subject Selector */}
          {mode === 'focus' && (
            <div className="mt-6 w-full max-w-xs">
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-2 text-center">Studying</label>
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                disabled={state === 'running'}
                className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/40 disabled:opacity-60"
              >
                <option value="">General Study</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          )}
        </Card>

        {/* Session Stats & History */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <StatCard icon={<Flame className="h-5 w-5" />} label="Today" value={formatMinutes(todayMinutes)} color="violet" />
            <StatCard icon={<Check className="h-5 w-5" />} label="Sessions" value={todaySessions.length} color="emerald" />
          </div>

          <Card className="p-5">
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white mb-3">Recent Sessions</h3>
            {sessions.length === 0 ? (
              <EmptyState
                icon={<Clock className="h-6 w-6" />}
                title="No sessions yet"
                description="Complete your first focus session to see it here."
              />
            ) : (
              <div className="space-y-2 max-h-[300px] overflow-y-auto scrollbar-thin">
                {sessions.slice(0, 10).map((s) => (
                  <div key={s.id} className="flex items-center gap-3 rounded-xl border border-slate-200/60 dark:border-white/5 p-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-500/10 text-violet-500">
                      {s.subject ? (
                        <div className="h-4 w-4 rounded-full" style={{ backgroundColor: s.subject.color }} />
                      ) : (
                        <BookOpen className="h-4 w-4" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 truncate">{s.subject?.name || 'General Study'}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{format(parseISO(s.completed_at), 'MMM d, h:mm a')}</p>
                    </div>
                    <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">{formatMinutes(s.duration_minutes)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
