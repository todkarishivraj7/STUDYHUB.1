import { useState, useRef, useEffect, useCallback } from 'react';
import { Bot, Send, Sparkles, Lightbulb, Calendar, Target, Clock, BookOpen, AlertCircle, RotateCcw, Zap } from 'lucide-react';
import { useAssignments } from '@/hooks/useAssignments';
import { useSubjects } from '@/hooks/useSubjects';
import { useStudySessions } from '@/hooks/useStudySessions';
import { Card } from '@/components/ui';
import { cn } from '@/lib/helpers';
import { classifyIntent, generateResponse, type ConversationTurn } from '@/lib/assistantEngine';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  error?: boolean;
}

const suggestions = [
  { icon: Calendar, text: 'What should I study today?' },
  { icon: Target, text: 'Which assignments are most urgent?' },
  { icon: BookOpen, text: 'Explain DBMS concepts' },
  { icon: Lightbulb, text: 'What is polymorphism in OOP?' },
  { icon: Clock, text: 'How much have I studied this week?' },
  { icon: Sparkles, text: 'Exam in 5 days, 3 hours per day' },
];

const WELCOME_MESSAGE = `Hi! I'm your AI Study Assistant. I analyze your real assignments, subjects, and study sessions to give you personalized recommendations.\n\nI can help you:\n  📋 Plan study schedules & prioritize tasks\n  📅 Check deadlines & track progress\n  📖 Explain academic concepts (DBMS, OOP, Data Structures, C, C++, Digital Techniques)\n  💡 Give study tips & motivation\n  📝 Generate day-wise exam prep plans\n\nJust ask me anything in natural language!`;

export function Assistant() {
  const { assignments } = useAssignments();
  const { subjects } = useSubjects();
  const { sessions } = useStudySessions();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const historyRef = useRef<ConversationTurn[]>([]);

  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: 'welcome',
        role: 'assistant',
        content: WELCOME_MESSAGE,
        timestamp: new Date(),
      }]);
    }
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = useCallback((text?: string) => {
    const message = (text ?? input).trim();
    if (!message || isTyping) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(36).slice(2),
      role: 'user',
      content: message,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    setError(false);

    const intent = classifyIntent(message);
    const userTurn: ConversationTurn = { role: 'user', content: message, intent };
    historyRef.current = [...historyRef.current, userTurn];

    // Simulate thinking time — proportional to response complexity
    const delay = 600 + Math.random() * 600;
    setTimeout(() => {
      try {
        const response = generateResponse(message, { assignments, subjects, sessions }, historyRef.current);
        historyRef.current = [...historyRef.current, { role: 'assistant', content: response }];
        setMessages((prev) => [...prev, {
          id: Math.random().toString(36).slice(2),
          role: 'assistant',
          content: response,
          timestamp: new Date(),
        }]);
      } catch {
        setMessages((prev) => [...prev, {
          id: Math.random().toString(36).slice(2),
          role: 'assistant',
          content: "Sorry, I ran into an issue generating a response. Please try asking your question again.",
          timestamp: new Date(),
          error: true,
        }]);
        setError(true);
      } finally {
        setIsTyping(false);
      }
    }, delay);
  }, [input, isTyping, assignments, subjects, sessions]);

  const handleReset = () => {
    setMessages([{
      id: 'welcome',
      role: 'assistant',
      content: WELCOME_MESSAGE,
      timestamp: new Date(),
    }]);
    historyRef.current = [];
    setError(false);
  };

  const pendingCount = assignments.filter((a) => a.status === 'pending').length;
  const overdueCount = assignments.filter((a) => {
    if (a.status !== 'pending' || !a.due_date) return false;
    return new Date(a.due_date) < new Date();
  }).length;

  return (
    <div className="space-y-6 animate-[fadeIn_0.4s_ease-out]">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Chat */}
        <Card className="lg:col-span-3 p-0 flex flex-col h-[calc(100vh-220px)] min-h-[500px] overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-white/10 px-6 py-4">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 text-white shadow-lg shadow-violet-500/25">
                  <Bot className="h-5 w-5" />
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-white dark:ring-slate-900" />
              </div>
              <div>
                <h3 className="font-display font-bold text-slate-900 dark:text-white">AI Study Assistant</h3>
                <div className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  <p className="text-xs text-emerald-500">Online · Intelligent rule-based engine</p>
                </div>
              </div>
            </div>
            <button
              onClick={handleReset}
              className="flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
              title="Clear conversation"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Clear
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto scrollbar-thin px-6 py-4 space-y-4">
            {messages.map((msg) => (
              <div key={msg.id} className={cn('flex gap-3 animate-[slideUp_0.3s_ease-out]', msg.role === 'user' && 'flex-row-reverse')}>
                <div className={cn(
                  'flex h-8 w-8 items-center justify-center rounded-xl shrink-0',
                  msg.role === 'assistant'
                    ? msg.error
                      ? 'bg-red-500/10 text-red-500'
                      : 'bg-gradient-to-br from-violet-500 to-indigo-600 text-white'
                    : 'bg-slate-200 dark:bg-white/10 text-slate-600 dark:text-slate-300'
                )}>
                  {msg.role === 'assistant' ? (msg.error ? <AlertCircle className="h-4 w-4" /> : <Bot className="h-4 w-4" />) : <Sparkles className="h-4 w-4" />}
                </div>
                <div className={cn(
                  'max-w-[78%] rounded-2xl px-4 py-3',
                  msg.role === 'assistant'
                    ? msg.error
                      ? 'bg-red-500/5 border border-red-500/20 text-red-600 dark:text-red-400 rounded-tl-sm'
                      : 'bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-200 rounded-tl-sm'
                    : 'bg-gradient-to-r from-violet-500 to-indigo-600 text-white rounded-tr-sm shadow-lg shadow-violet-500/10'
                )}>
                  <p className="text-sm whitespace-pre-line leading-relaxed">{msg.content}</p>
                  <p className={cn(
                    'text-[10px] mt-1.5',
                    msg.role === 'assistant' ? 'text-slate-400 dark:text-slate-500' : 'text-violet-200'
                  )}>
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex gap-3 animate-[fadeIn_0.3s_ease-out]">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 text-white shrink-0">
                  <Bot className="h-4 w-4" />
                </div>
                <div className="bg-slate-100 dark:bg-white/5 rounded-2xl rounded-tl-sm px-4 py-3.5">
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      <span className="h-2 w-2 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="h-2 w-2 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="h-2 w-2 rounded-full bg-violet-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                    <span className="text-xs text-slate-400">Analyzing your data...</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="border-t border-slate-200/60 dark:border-white/10 p-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask me anything about your studies..."
                disabled={isTyping}
                className="flex-1 rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-3 text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40 transition-all disabled:opacity-50"
              />
              <button
                onClick={() => handleSend()}
                disabled={!input.trim() || isTyping}
                className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-r from-violet-500 to-indigo-600 text-white shadow-lg shadow-violet-500/25 hover:shadow-violet-500/40 hover:brightness-110 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>
          </div>
        </Card>

        {/* Sidebar: Suggestions & Stats */}
        <div className="space-y-4">
          {/* How it works */}
          <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-indigo-500/10 p-4 border border-violet-500/10">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-4 w-4 text-violet-500" />
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">How I work</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              I analyze your real assignments, subjects, and focus sessions in real time to give you personalized recommendations. I understand natural language — no need for exact commands.
            </p>
          </div>

          {/* Quick Questions */}
          <div>
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white px-1 mb-2">Quick Questions</h3>
            <div className="space-y-2">
              {suggestions.map((s, i) => {
                const Icon = s.icon;
                return (
                  <button
                    key={i}
                    onClick={() => handleSend(s.text)}
                    disabled={isTyping}
                    className="w-full flex items-center gap-3 rounded-xl border border-slate-200/60 dark:border-white/5 bg-white/50 dark:bg-white/5 p-3 text-left hover:border-violet-500/30 hover:bg-violet-500/5 transition-all group disabled:opacity-50"
                  >
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-violet-500/10 text-violet-500 group-hover:bg-violet-500/20 transition-colors shrink-0">
                      <Icon className="h-4 w-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-600 dark:text-slate-300">{s.text}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Stats */}
          <div className="rounded-2xl bg-white/50 dark:bg-white/5 border border-slate-200/60 dark:border-white/5 p-4">
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="h-4 w-4 text-violet-500" />
              <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">Your Stats</span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 dark:text-slate-400">Pending assignments</span>
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{pendingCount}</span>
              </div>
              {overdueCount > 0 && (
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500 dark:text-slate-400">Overdue</span>
                  <span className="text-xs font-bold text-red-500">{overdueCount}</span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 dark:text-slate-400">Subjects tracked</span>
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{subjects.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 dark:text-slate-400">Focus sessions</span>
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{sessions.length}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
