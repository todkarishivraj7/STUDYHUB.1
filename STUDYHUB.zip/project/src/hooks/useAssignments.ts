import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Assignment, AssignmentInput } from '@/lib/types';

export function useAssignments() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAssignments = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('assignments')
      .select('*, subject:subjects(*)')
      .order('due_date', { ascending: true, nullsFirst: false });
    if (error) {
      console.error('Error fetching assignments:', error);
    } else {
      setAssignments(data as Assignment[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchAssignments(); }, [fetchAssignments]);

  const createAssignment = async (input: AssignmentInput) => {
    const { data, error } = await supabase
      .from('assignments')
      .insert(input)
      .select('*, subject:subjects(*)')
      .single();
    if (error) throw error;
    setAssignments((prev) => [...prev, data as Assignment].sort((a, b) => {
      if (!a.due_date) return 1;
      if (!b.due_date) return -1;
      return a.due_date.localeCompare(b.due_date);
    }));
    return data;
  };

  const updateAssignment = async (id: string, updates: Partial<AssignmentInput>) => {
    const { data, error } = await supabase
      .from('assignments')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*, subject:subjects(*)')
      .single();
    if (error) throw error;
    setAssignments((prev) => prev.map((a) => (a.id === id ? data as Assignment : a)));
    return data;
  };

  const deleteAssignment = async (id: string) => {
    const { error } = await supabase.from('assignments').delete().eq('id', id);
    if (error) throw error;
    setAssignments((prev) => prev.filter((a) => a.id !== id));
  };

  const toggleStatus = async (assignment: Assignment) => {
    return updateAssignment(assignment.id, {
      status: assignment.status === 'pending' ? 'completed' : 'pending',
    });
  };

  return { assignments, loading, createAssignment, updateAssignment, deleteAssignment, toggleStatus, refetch: fetchAssignments };
}
