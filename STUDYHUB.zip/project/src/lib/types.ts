export interface Subject {
  id: string;
  name: string;
  color: string;
  goal_hours_per_week: number;
  created_at: string;
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  subject_id: string | null;
  due_date: string | null;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'completed';
  created_at: string;
  updated_at: string;
  subject?: Subject;
}

export interface StudySession {
  id: string;
  subject_id: string | null;
  duration_minutes: number;
  session_type: string;
  completed_at: string;
  subject?: Subject;
}

export interface UserPreferences {
  id: string;
  theme: 'dark' | 'light';
  daily_study_goal: number;
  pomodoro_focus: number;
  pomodoro_break: number;
  student_name: string;
}

export type AssignmentInput = Omit<Assignment, 'id' | 'created_at' | 'updated_at' | 'subject'>;
export type SubjectInput = Pick<Subject, 'name' | 'color' | 'goal_hours_per_week'>;
