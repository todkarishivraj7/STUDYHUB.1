import { format, parseISO, isToday, isTomorrow, subDays, differenceInDays, addDays } from 'date-fns';
import type { Assignment, StudySession, Subject } from './types';
import { findConcept, getSubjectOverview, listSupportedSubjects, conceptKnowledge } from './conceptKnowledge';

export interface AssistantContext {
  assignments: Assignment[];
  subjects: Subject[];
  sessions: StudySession[];
}

export interface ConversationTurn {
  role: 'user' | 'assistant';
  content: string;
  intent?: Intent;
}

export type Intent =
  | 'greeting'
  | 'schedule_today'
  | 'schedule_week'
  | 'prioritize'
  | 'deadline_check'
  | 'stats'
  | 'study_tips'
  | 'exam_prep'
  | 'focus_tips'
  | 'motivation'
  | 'subject_info'
  | 'concept_explanation'
  | 'pomodoro_info'
  | 'help'
  | 'fallback';

interface IntentDef {
  intent: Intent;
  keywords: string[];
  phrases: string[];
  weight: number;
}

const intentDefs: IntentDef[] = [
  {
    intent: 'greeting',
    keywords: [],
    phrases: ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening', 'howdy', 'sup', 'yo'],
    weight: 10,
  },
  {
    intent: 'schedule_today',
    keywords: ['today', 'tonight', 'now', 'right now'],
    phrases: ['what should i study', 'what to study', 'study plan', 'plan my day', 'what can i do', 'what do i do', 'help me plan', 'study now', 'start studying', 'what should i do'],
    weight: 8,
  },
  {
    intent: 'schedule_week',
    keywords: ['week', 'weekly', 'this week', 'next week', '7 day'],
    phrases: ['study schedule', 'study plan for', 'plan my week', 'weekly plan', 'weekly schedule', 'plan ahead', 'upcoming'],
    weight: 7,
  },
  {
    intent: 'prioritize',
    keywords: ['urgent', 'priority', 'prioritize', 'important', 'most important', 'critical', 'pressing', 'top priority', 'first'],
    phrases: ['what should i do first', 'what is most important', 'which assignment', 'what is urgent', 'rank my', 'order my', 'what comes first', 'most critical'],
    weight: 8,
  },
  {
    intent: 'deadline_check',
    keywords: ['deadline', 'due', 'overdue', 'late', 'due date', 'when is'],
    phrases: ['when is', 'what is due', 'what is overdue', 'what is late', 'due soon', 'coming up', 'deadline'],
    weight: 7,
  },
  {
    intent: 'stats',
    keywords: ['progress', 'stats', 'statistics', 'how much', 'total', 'summary', 'report', 'overview', 'track', 'logged', 'completed'],
    phrases: ['how much have i studied', 'study time', 'this week', 'my progress', 'my stats', 'show me my', 'give me a report', 'how am i doing', 'track record', 'how many sessions'],
    weight: 6,
  },
  {
    intent: 'study_tips',
    keywords: ['tip', 'tips', 'advice', 'technique', 'strategies', 'strategy', 'method', 'methods', 'how to study', 'better'],
    phrases: ['study tip', 'how to study', 'study advice', 'study strategies', 'study techniques', 'better grades', 'study more effectively', 'improve my', 'better at studying'],
    weight: 6,
  },
  {
    intent: 'exam_prep',
    keywords: ['exam', 'test', 'midterm', 'final', 'quiz', 'prepare', 'preparation', 'cram', 'review'],
    phrases: ['exam prep', 'prepare for exam', 'study for test', 'pass my', 'ace my', 'get ready for', 'test tomorrow', 'exam tomorrow', 'cram for', 'review for'],
    weight: 7,
  },
  {
    intent: 'focus_tips',
    keywords: ['focus', 'concentrate', 'distraction', 'distracted', 'attention', 'pomodoro', 'procrastinat'],
    phrases: ['how to focus', 'cant focus', "can't focus", 'keep getting distracted', 'stay focused', 'concentrate better', 'avoid distraction', 'stop procrastinating', 'pomodoro technique', 'how does pomodoro'],
    weight: 6,
  },
  {
    intent: 'motivation',
    keywords: ['motivat', 'stress', 'stressed', 'overwhelm', 'overwhelmed', 'tired', 'burnout', 'burnt out', 'anxious', 'anxiety', 'giving up', 'cant do', "can't do", 'hopeless', 'depressed', 'exhausted'],
    phrases: ['i am stressed', 'im stressed', "i'm stressed", 'feel overwhelmed', 'losing motivation', 'no motivation', 'cant keep up', "can't keep up", 'burning out', 'i am tired', 'so tired', 'giving up', 'feel hopeless', 'too much work', 'falling behind'],
    weight: 7,
  },
  {
    intent: 'concept_explanation',
    keywords: ['explain', 'concept', 'concepts', 'define', 'definition', 'what is', 'what are', 'meaning of', 'tell me about', 'elaborate', 'describe', 'understand', 'learn'],
    phrases: ['explain dbms', 'explain oop', 'explain data structure', 'explain c++', 'explain c programming', 'what is dbms', 'what is oop', 'what is normalization', 'what is pointer', 'what is polymorphism', 'what is inheritance', 'what is encapsulation', 'what is a stack', 'what is a queue', 'what is a tree', 'what is a graph', 'what is boolean', 'what is logic gate', 'what is flip flop', 'what is sql', 'what is array', 'what is linked list', 'what is acid', 'what is indexing', 'what is abstraction', 'what is a template', 'what is stl', 'what is constructor', 'what is struct', 'what is memory management', 'what is digital electronics', 'what is binary', 'what is number system', 'define dbms', 'define normalization', 'define oop', 'define polymorphism', 'define inheritance', 'define encapsulation', 'define abstraction', 'define pointer', 'concept of', 'concept in dbms', 'concept in oop', 'concept in data structure', 'dbms concept', 'oop concept', 'data structure concept', 'digital technique', 'digital electronics', 'logic gate', 'logic gates', 'boolean algebra', 'flip flop', 'karnaugh', 'k-map', 'binary number', 'hexadecimal', 'octal', 'entity relationship', 'er model', 'er diagram', 'sql join', 'inner join', 'left join', 'right join', 'normalization', 'normal form', '1nf', '2nf', '3nf', 'bcnf', 'acid properties', 'atomicity', 'consistency', 'isolation', 'durability', 'indexing', 'b-tree', 'encapsulation', 'inheritance', 'polymorphism', 'abstraction', 'overloading', 'overriding', 'abstract class', 'interface', 'array', 'linked list', 'stack', 'queue', 'tree', 'binary tree', 'bst', 'binary search tree', 'graph', 'bfs', 'dfs', 'adjacency', 'heap', 'pointer', 'malloc', 'calloc', 'free', 'dynamic memory', 'struct', 'structure', 'stl', 'standard template library', 'template', 'constructor', 'destructor', 'copy constructor'],
    weight: 9,
  },
  {
    intent: 'subject_info',
    keywords: ['subject', 'subjects', 'course', 'courses', 'class', 'classes'],
    phrases: ['my subjects', 'which subjects', 'subject info', 'tell me about my subjects', 'how are my subjects', 'subject goals', 'subject progress', 'all subjects'],
    weight: 5,
  },
  {
    intent: 'pomodoro_info',
    keywords: ['pomodoro', 'timer', 'focus mode', 'focus session', '25 minute', 'break'],
    phrases: ['how does pomodoro work', 'what is pomodoro', 'how to use pomodoro', 'how does the timer work', 'how does focus mode work', 'focus session', 'pomodoro timer'],
    weight: 6,
  },
  {
    intent: 'help',
    keywords: ['help', 'what can you do', 'what do you do', 'commands', 'capabilities'],
    phrases: ['what can you do', 'what do you do', 'how can you help', 'what are your features', 'help me', 'what are you'],
    weight: 4,
  },
];

function scoreIntent(query: string): Intent {
  const q = query.toLowerCase().trim();
  let best: Intent = 'fallback';
  let bestScore = 0;

  // ── Priority check: concept explanation ───────────────
  // If the query matches a known concept from our knowledge base, immediately
  // classify it as concept_explanation — this takes priority over everything else
  // so "Explain DBMS concepts" never falls through to assignment matching.
  const conceptMatch = findConcept(query);
  if (conceptMatch) {
    // Words that indicate the user is asking for an explanation, not their subject progress
    const explanationWords = ['explain', 'what is', 'what are', 'define', 'definition', 'concept', 'meaning', 'describe', 'elaborate', 'understand', 'learn', 'tell me about', 'how does', 'how do'];
    const wantsExplanation = explanationWords.some((w) => q.includes(w));

    // Also check if the query directly names a known topic/alias without mentioning "my subjects" or "progress"
    const isSubjectProgressQuery = q.includes('my subject') || q.includes('my course') || q.includes('subject progress') || q.includes('subject goals') || q.includes('how are my subjects');

    if (wantsExplanation || !isSubjectProgressQuery) {
      return 'concept_explanation';
    }
  }

  for (const def of intentDefs) {
    let score = 0;
    for (const phrase of def.phrases) {
      if (q.includes(phrase)) {
        score += def.weight;
        if (q === phrase || q.startsWith(phrase)) score += 3;
      }
    }
    for (const keyword of def.keywords) {
      if (q.includes(keyword)) score += Math.max(1, Math.floor(def.weight / 3));
    }
    if (score > bestScore) {
      bestScore = score;
      best = def.intent;
    }
  }

  // Special handling: "schedule" + "today" → schedule_today, but "schedule" + "week" → schedule_week
  if (q.includes('schedule') || q.includes('plan')) {
    if (q.includes('today') || q.includes('now') || q.includes('tonight')) {
      if (bestScore < 8) best = 'schedule_today';
    } else if (q.includes('week') || q.includes('next')) {
      if (bestScore < 8) best = 'schedule_week';
    }
  }

  return best;
}

function getDaysUntil(dateStr: string | null): number | null {
  if (!dateStr) return null;
  return differenceInDays(parseISO(dateStr), new Date());
}

function dueText(days: number | null): string {
  if (days === null) return 'no due date';
  if (days < 0) return `${Math.abs(days)} day${Math.abs(days) === 1 ? '' : 's'} overdue`;
  if (days === 0) return 'due today';
  if (days === 1) return 'due tomorrow';
  return `due in ${days} days`;
}

function priorityRank(p: string): number {
  return p === 'high' ? 0 : p === 'medium' ? 1 : 2;
}

export function classifyIntent(query: string): Intent {
  return scoreIntent(query);
}

export function generateResponse(
  query: string,
  ctx: AssistantContext,
  history: ConversationTurn[]
): string {
  const intent = classifyIntent(query);
  const { assignments, subjects, sessions } = ctx;
  const pending = assignments.filter((a) => a.status === 'pending');
  const completed = assignments.filter((a) => a.status === 'completed');
  const overdue = pending.filter((a) => { const d = getDaysUntil(a.due_date); return d !== null && d < 0; });
  const dueSoon = pending.filter((a) => { const d = getDaysUntil(a.due_date); return d !== null && d >= 0 && d <= 3; });
  const sortedPending = [...pending].sort((a, b) => {
    const ad = getDaysUntil(a.due_date) ?? 999;
    const bd = getDaysUntil(b.due_date) ?? 999;
    if (ad !== bd) return ad - bd;
    return priorityRank(a.priority) - priorityRank(b.priority);
  });
  const urgent = sortedPending.filter((a) => { const d = getDaysUntil(a.due_date); return d !== null && d <= 3; });

  // Context-aware greeting follow-up
  const lastUserTurn = [...history].reverse().find((t) => t.role === 'user');

  switch (intent) {
    // ── GREETING ──────────────────────────────────────
    case 'greeting': {
      const hour = new Date().getHours();
      const timeGreeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
      let msg = `${timeGreeting}! `;
      if (pending.length > 0) {
        msg += `You have ${pending.length} pending ${pending.length === 1 ? 'assignment' : 'assignments'}`;
        if (overdue.length > 0) msg += ` (${overdue.length} overdue)`;
        msg += `. `;
      }
      if (dueSoon.length > 0) {
        msg += `The most urgent is **${dueSoon[0].title}** ${dueText(getDaysUntil(dueSoon[0].due_date))}. `;
      }
      msg += `\n\nWhat can I help you with? You can ask me to plan your study schedule, prioritize your tasks, or give you study tips.`;
      return msg;
    }

    // ── SCHEDULE TODAY ────────────────────────────────
    case 'schedule_today': {
      if (pending.length === 0 && subjects.length === 0) {
        return "You don't have any pending assignments or subjects yet. Head to the Study Planner to add subjects, then create some assignments — I'll build you a personalized schedule from there.";
      }

      // Parse available time from query (e.g. "2 hours", "90 minutes")
      let availableMinutes = 120;
      const hourMatch = query.match(/(\d+)\s*(?:hr|hour|hrs|hours)/i);
      const minMatch = query.match(/(\d+)\s*(?:min|minute|minutes)/i);
      if (hourMatch) availableMinutes = parseInt(hourMatch[1]) * 60;
      if (minMatch) availableMinutes = parseInt(minMatch[1]);
      if (hourMatch && minMatch) availableMinutes = parseInt(hourMatch[1]) * 60 + parseInt(minMatch[1]);

      let response = `Here's your personalized study plan for today (${formatMinutes(availableMinutes)} available):\n\n`;
      let remaining = availableMinutes;
      const blocks: { label: string; sub: string; mins: number; emoji: string }[] = [];

      // Priority 1: Urgent assignments
      if (urgent.length > 0) {
        for (const a of urgent.slice(0, 3)) {
          if (remaining < 25) break;
          const blockMins = Math.min(50, remaining);
          blocks.push({
            label: a.title,
            sub: `${a.subject?.name || 'General'} — ${dueText(getDaysUntil(a.due_date))} — ${a.priority} priority`,
            mins: blockMins,
            emoji: '⚠️',
          });
          remaining -= blockMins;
        }
      }

      // Priority 2: Subjects behind their weekly goal
      const behindSubjects = subjects.map((s) => {
        const weeklyMins = sessions
          .filter((sess) => sess.subject_id === s.id)
          .filter((sess) => { const days = Math.floor((Date.now() - new Date(sess.completed_at).getTime()) / (1000 * 60 * 60 * 24)); return days <= 7; })
          .reduce((sum, sess) => sum + sess.duration_minutes, 0);
        const goalMins = s.goal_hours_per_week * 60;
        return { ...s, weeklyMins, goalMins, deficit: goalMins - weeklyMins };
      }).filter((s) => s.deficit > 0).sort((a, b) => b.deficit - a.deficit);

      for (const s of behindSubjects.slice(0, 3)) {
        if (remaining < 25) break;
        const blockMins = Math.min(Math.min(s.deficit, 45), remaining);
        if (blockMins < 25) continue;
        blocks.push({
          label: `Review ${s.name}`,
          sub: `Behind weekly goal: ${formatMinutes(s.weeklyMins)} / ${formatMinutes(s.goalMins)} (${Math.round((s.weeklyMins / s.goalMins) * 100)}%)`,
          mins: blockMins,
          emoji: '📚',
        });
        remaining -= blockMins;
      }

      // Priority 3: Other pending assignments (furthest out)
      const nonUrgent = sortedPending.filter((a) => !urgent.includes(a));
      for (const a of nonUrgent.slice(0, 2)) {
        if (remaining < 25) break;
        const blockMins = Math.min(25, remaining);
        blocks.push({
          label: `Start: ${a.title}`,
          sub: `${a.subject?.name || 'General'} — ${dueText(getDaysUntil(a.due_date))}`,
          mins: blockMins,
          emoji: '📝',
        });
        remaining -= blockMins;
      }

      if (blocks.length === 0) {
        return `You're in great shape! With ${formatMinutes(availableMinutes)} available, you've already covered your urgent items and all subjects are on track. Use this time for review, practice problems, or getting ahead on upcoming assignments.`;
      }

      blocks.forEach((b, i) => {
        response += `${i + 1}. ${b.emoji} **${b.label}** — ${formatMinutes(b.mins)}\n   ${b.sub}\n`;
      });

      const totalPlanned = availableMinutes - remaining;
      response += `\n**Total planned:** ${formatMinutes(totalPlanned)}\n`;
      response += `**Free time remaining:** ${formatMinutes(remaining)}\n\n`;
      response += `💡 Use Focus Mode with Pomodoro sessions (25 min focus + 5 min break) to work through each block. Check off assignments as you complete them!`;

      return response;
    }

    // ── SCHEDULE WEEK ─────────────────────────────────
    case 'schedule_week': {
      if (pending.length === 0 && subjects.length === 0) {
        return "You don't have any subjects or assignments set up yet. Add subjects in the Study Planner and create assignments — then I'll build you a full weekly schedule.";
      }

      const weekPlan: { day: string; blocks: { label: string; mins: number; sub: string }[] }[] = [];
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const todayIdx = (new Date().getDay() + 6) % 7;

      // Distribute urgent assignments across the next few days
      const allPending = [...sortedPending];
      let dayOffset = 0;
      let dayIdx = todayIdx;

      while (allPending.length > 0 && weekPlan.length < 7) {
        const dayAssignments = allPending.filter((a) => {
          const d = getDaysUntil(a.due_date);
          return d !== null && d >= dayOffset && d <= dayOffset + 1;
        });

        const blocks: { label: string; mins: number; sub: string }[] = [];

        for (const a of dayAssignments) {
          blocks.push({
            label: a.title,
            mins: 50,
            sub: `${a.subject?.name || 'General'} — ${dueText(getDaysUntil(a.due_date))}`,
          });
          const idx = allPending.indexOf(a);
          if (idx >= 0) allPending.splice(idx, 1);
        }

        // Add a subject review block if there's room
        if (blocks.length < 2 && subjects.length > 0) {
          const subj = subjects[dayIdx % subjects.length];
          blocks.push({
            label: `Review ${subj.name}`,
            mins: 30,
            sub: `Weekly goal: ${subj.goal_hours_per_week}h`,
          });
        }

        if (blocks.length > 0) {
          weekPlan.push({ day: days[dayIdx], blocks });
        }

        dayOffset++;
        dayIdx = (dayIdx + 1) % 7;
      }

      if (weekPlan.length === 0) {
        return "You have no pending assignments with due dates this week. Use this time to review your subjects, practice problems, or get ahead. Add assignments with due dates and I'll create a detailed weekly plan for you.";
      }

      let response = `Here's your weekly study plan:\n\n`;
      weekPlan.forEach((d) => {
        const totalMins = d.blocks.reduce((s, b) => s + b.mins, 0);
        response += `**${d.day}** (${formatMinutes(totalMins)}):\n`;
        d.blocks.forEach((b) => {
          response += `  • ${b.label} — ${formatMinutes(b.mins)} (${b.sub})\n`;
        });
        response += `\n`;
      });

      response += `💡 Spread your work across the week and don't cram everything into one day. Use Focus Mode for each block.`;
      return response;
    }

    // ── PRIORITIZE ────────────────────────────────────
    case 'prioritize': {
      if (pending.length === 0) {
        return "You have no pending assignments to prioritize! Everything is either completed or you haven't added any yet. Great job staying on top of things — or head to Assignments to create new ones.";
      }

      // Build a ranked list combining due date urgency + priority level
      const ranked = [...pending].map((a) => {
        const days = getDaysUntil(a.due_date);
        let urgencyScore = 0;
        if (days === null) urgencyScore = 50;
        else if (days < 0) urgencyScore = 100 + Math.abs(days) * 10;
        else urgencyScore = Math.max(0, 50 - days * 5);
        const priorityScore = a.priority === 'high' ? 30 : a.priority === 'medium' ? 15 : 5;
        return { assignment: a, score: urgencyScore + priorityScore, days };
      }).sort((a, b) => b.score - a.score);

      let response = `Here are your pending assignments ranked by priority (urgency + importance):\n\n`;
      ranked.slice(0, 6).forEach((item, i) => {
        const a = item.assignment;
        const marker = i === 0 ? '🔴' : i === 1 ? '🟠' : i === 2 ? '🟡' : '⚪';
        response += `${i + 1}. ${marker} **${a.title}**\n`;
        response += `   ${dueText(item.days)} · ${a.priority} priority${a.subject ? ` · ${a.subject.name}` : ''}\n`;
        if (item.days !== null && item.days < 0) {
          response += `   ⚠️ This is overdue — make it your top priority!\n`;
        }
      });

      response += `\n**My recommendation:** ${ranked[0] ? `Start with **${ranked[0].assignment.title}**` : 'Start with your first task'} — it has the highest combined urgency and importance score. Complete it before moving to the next one.`;

      if (overdue.length > 0) {
        response += `\n\n⚠️ You have ${overdue.length} overdue ${overdue.length === 1 ? 'assignment' : 'assignments'}. Address these first to avoid falling further behind.`;
      }

      return response;
    }

    // ── DEADLINE CHECK ────────────────────────────────
    case 'deadline_check': {
      if (pending.length === 0) {
        return "You have no pending assignments, so no deadlines to worry about! If you've completed everything, consider reviewing material or getting ahead.";
      }

      let response = `Here's your deadline overview:\n\n`;

      if (overdue.length > 0) {
        response += `🔴 **Overdue (${overdue.length}):**\n`;
        overdue.forEach((a) => {
          response += `  • ${a.title} — was due ${format(parseISO(a.due_date!), 'MMM d')}${a.subject ? ` (${a.subject.name})` : ''}\n`;
        });
        response += `\n`;
      }

      if (dueSoon.length > 0) {
        response += `🟠 **Due in the next 3 days (${dueSoon.length}):**\n`;
        dueSoon.forEach((a) => {
          response += `  • ${a.title} — ${dueText(getDaysUntil(a.due_date))}${a.subject ? ` (${a.subject.name})` : ''}\n`;
        });
        response += `\n`;
      }

      const farOut = pending.filter((a) => { const d = getDaysUntil(a.due_date); return d !== null && d > 3; });
      if (farOut.length > 0) {
        response += `🟢 **Upcoming (more than 3 days out):**\n`;
        farOut.slice(0, 5).forEach((a) => {
          response += `  • ${a.title} — ${dueText(getDaysUntil(a.due_date))}${a.subject ? ` (${a.subject.name})` : ''}\n`;
        });
        if (farOut.length > 5) response += `  ...and ${farOut.length - 5} more\n`;
      }

      const noDate = pending.filter((a) => !a.due_date);
      if (noDate.length > 0) {
        response += `\n📅 **No due date (${noDate.length}):** Consider adding deadlines to stay organized.\n`;
      }

      return response;
    }

    // ── STATS / PROGRESS ──────────────────────────────
    case 'stats': {
      const now = new Date();
      const weekAgo = subDays(now, 7);
      const weeklySessions = sessions.filter((s) => new Date(s.completed_at) >= weekAgo);
      const weeklyMinutes = weeklySessions.reduce((sum, s) => sum + s.duration_minutes, 0);
      const totalMinutes = sessions.reduce((sum, s) => sum + s.duration_minutes, 0);
      const todayMinutes = sessions.filter((s) => isToday(parseISO(s.completed_at))).reduce((sum, s) => sum + s.duration_minutes, 0);
      const completionRate = assignments.length > 0 ? Math.round((completed.length / assignments.length) * 100) : 0;

      let response = `📊 **Your Study Progress Report**\n\n`;
      response += `**Today:**\n`;
      response += `  • Focus time: ${formatMinutes(todayMinutes)}\n`;
      response += `  • Sessions completed: ${sessions.filter((s) => isToday(parseISO(s.completed_at))).length}\n\n`;
      response += `**This Week:**\n`;
      response += `  • Study time: ${formatMinutes(weeklyMinutes)}\n`;
      response += `  • Sessions: ${weeklySessions.length}\n`;
      response += `  • Daily average: ${formatMinutes(Math.round(weeklyMinutes / 7))}\n\n`;
      response += `**All Time:**\n`;
      response += `  • Total study time: ${formatMinutes(totalMinutes)}\n`;
      response += `  • Total sessions: ${sessions.length}\n\n`;
      response += `**Assignments:**\n`;
      response += `  • Total: ${assignments.length}\n`;
      response += `  • Completed: ${completed.length} (${completionRate}%)\n`;
      response += `  • Pending: ${pending.length}\n`;
      if (overdue.length > 0) response += `  • Overdue: ${overdue.length} ⚠️\n`;

      if (subjects.length > 0) {
        const subjectStats = subjects.map((s) => {
          const mins = sessions.filter((sess) => sess.subject_id === s.id).reduce((sum, sess) => sum + sess.duration_minutes, 0);
          const weeklyMins = sessions
            .filter((sess) => sess.subject_id === s.id)
            .filter((sess) => new Date(sess.completed_at) >= weekAgo)
            .reduce((sum, sess) => sum + sess.duration_minutes, 0);
          return { name: s.name, mins, weeklyMins, goal: s.goal_hours_per_week * 60 };
        }).sort((a, b) => b.mins - a.mins);

        response += `\n**Study time by subject:**\n`;
        subjectStats.forEach((s) => {
          const pct = s.goal > 0 ? Math.round((s.weeklyMins / s.goal) * 100) : 0;
          response += `  • ${s.name}: ${formatMinutes(s.mins)} total · ${formatMinutes(s.weeklyMins)} this week (${pct}% of goal)\n`;
        });

        const topSubject = subjectStats[0];
        if (topSubject && topSubject.mins > 0) {
          response += `\n🏆 Your most studied subject is **${topSubject.name}** with ${formatMinutes(topSubject.mins)}.`;
        }
        const leastStudied = subjectStats.filter((s) => s.mins > 0).sort((a, b) => a.mins - b.mins)[0];
        if (leastStudied && subjectStats.length > 1) {
          response += `\n💡 Consider spending more time on **${leastStudied.name}** — it has the least study time.`;
        }
      }

      return response;
    }

    // ── STUDY TIPS ────────────────────────────────────
    case 'study_tips': {
      const tipSets = [
        {
          title: 'Evidence-Based Study Techniques',
          tips: [
            '**Active Recall** — Instead of re-reading notes, close the book and try to write down everything you remember. Then check what you missed. This forces your brain to retrieve information, which strengthens memory far more than passive review.',
            '**Spaced Repetition** — Review material at increasing intervals: after 1 day, then 3 days, then 1 week, then 2 weeks. Tools like flashcards work great for this. Cramming feels productive but fades fast; spaced repetition builds lasting memory.',
            '**The Feynman Technique** — Pick a concept and explain it out loud as if teaching a 12-year-old. Use simple words and no jargon. Wherever you stumble or use complex terms, you\'ve found a gap in your understanding — go back and study that part.',
            '**Interleaving** — Instead of studying one topic for hours, mix related topics in a single session. It feels harder but improves your ability to distinguish between problem types and apply the right method on exams.',
          ],
        },
        {
          title: 'Note-Taking Strategies',
          tips: [
            '**Cornell Method** — Divide your page into three sections: cues (left), notes (right), and summary (bottom). Take notes during class, write key questions in the cue column, and summarize each page after class. This creates a built-in study guide.',
            '**Mind Mapping** — Start with the central topic in the middle of the page and branch out with related concepts. This visual approach helps you see connections between ideas and is especially useful for understanding big-picture relationships.',
            '**The SQ3R Method** — Survey, Question, Read, Recite, Review. Before reading a chapter, skim headings and form questions. Then read actively to answer those questions. Recite key points from memory, then review periodically.',
            '**Dual Coding** — Combine words with visuals. Draw diagrams, timelines, or flowcharts alongside your written notes. Your brain processes verbal and visual information through different channels — using both doubles your retrieval paths.',
          ],
        },
      ];
      const set = tipSets[Math.floor(Math.random() * tipSets.length)];
      let response = `Here are ${set.title.toLowerCase()}:\n\n`;
      set.tips.forEach((tip, i) => {
        response += `${i + 1}. ${tip}\n\n`;
      });
      response += `💡 Pick one technique to try this week. Don't try to change everything at once — small, consistent improvements compound over time.`;
      return response;
    }

    // ── EXAM PREP ─────────────────────────────────────
    case 'exam_prep': {
      // Parse exam date from query (e.g. "exam in 5 days", "exam on Oct 15")
      let daysToExam = 7; // default to 1 week
      const daysMatch = query.match(/(\d+)\s*day/i);
      if (daysMatch) daysToExam = parseInt(daysMatch[1]);
      const weekMatch = query.match(/(\d+)\s*week/i);
      if (weekMatch) daysToExam = parseInt(weekMatch[1]) * 7;

      // Parse available hours per day from query
      let hoursPerDay = 3; // default
      const hrsMatch = query.match(/(\d+)\s*(?:hr|hour|hrs|hours)/i);
      if (hrsMatch) hoursPerDay = parseInt(hrsMatch[1]);

      // Parse number of chapters/topics from query
      let numChapters = 0;
      const chapMatch = query.match(/(\d+)\s*(?:chapter|chapters|topic|topics|unit|units)/i);
      if (chapMatch) numChapters = parseInt(chapMatch[1]);

      // Determine which subject the exam is for
      let examSubject: string | null = null;
      for (const sk of conceptKnowledge) {
        for (const alias of sk.aliases) {
          if (query.toLowerCase().includes(alias)) {
            examSubject = sk.subject;
            break;
          }
        }
        if (examSubject) break;
      }
      // Also check user's own subjects
      if (!examSubject) {
        for (const s of subjects) {
          if (query.toLowerCase().includes(s.name.toLowerCase())) {
            examSubject = s.name;
            break;
          }
        }
      }

      // If no chapters specified but we know the subject, use its concept count
      if (numChapters === 0 && examSubject) {
        const sk = conceptKnowledge.find((k) => k.subject === examSubject);
        if (sk) numChapters = sk.concepts.length;
      }
      if (numChapters === 0) numChapters = Math.min(8, Math.ceil(daysToExam / 2)); // default: ~1 chapter per 2 days

      const totalStudyMinutes = daysToExam * hoursPerDay * 60;
      const minutesPerChapter = Math.floor(totalStudyMinutes / numChapters);
      const reviewMinutes = Math.floor(minutesPerChapter * 0.3); // 30% of each chapter for review

      // Get chapter names from knowledge base if available
      let chapterNames: string[] = [];
      if (examSubject) {
        const sk = conceptKnowledge.find((k) => k.subject === examSubject);
        if (sk) chapterNames = sk.concepts.map((c) => c.topic);
      }
      // Pad with generic names if not enough
      while (chapterNames.length < numChapters) {
        chapterNames.push(`Chapter ${chapterNames.length + 1}`);
      }

      let response = `📅 **Day-wise Exam Preparation Plan**\n\n`;
      response += `**Exam:** ${examSubject || 'General'}\n`;
      response += `**Days until exam:** ${daysToExam}\n`;
      response += `**Study time per day:** ${hoursPerDay} hours (${formatMinutes(hoursPerDay * 60)})\n`;
      response += `**Chapters to cover:** ${numChapters}\n`;
      response += `**Time per chapter:** ${formatMinutes(minutesPerChapter)} (study + review)\n\n`;

      // Distribute chapters across days
      const days = [];
      const chaptersPerDay = Math.ceil(numChapters / (daysToExam - 1)); // leave last day for full review
      let chapterIdx = 0;
      const today = new Date();

      for (let d = 0; d < daysToExam; d++) {
        const date = addDays(today, d);
        const dayLabel = format(date, 'EEE, MMM d');
        const isLastDay = d === daysToExam - 1;

        if (isLastDay) {
          days.push({
            label: dayLabel,
            blocks: [
              { task: 'Full review of all chapters', mins: hoursPerDay * 60 * 0.6, type: 'review' },
              { task: 'Practice problems / mock test', mins: hoursPerDay * 60 * 0.4, type: 'practice' },
            ],
          });
        } else {
          const dayChapters: string[] = [];
          for (let c = 0; c < chaptersPerDay && chapterIdx < numChapters; c++) {
            dayChapters.push(chapterNames[chapterIdx]);
            chapterIdx++;
          }
          const blocks: { task: string; mins: number; type: string }[] = [];
          const studyMinsPerChapter = Math.floor((hoursPerDay * 60) / Math.max(dayChapters.length, 1) * 0.7);
          const reviewMins = Math.floor((hoursPerDay * 60) / Math.max(dayChapters.length, 1) * 0.3);

          dayChapters.forEach((ch) => {
            blocks.push({ task: `Study: ${ch}`, mins: studyMinsPerChapter, type: 'study' });
            blocks.push({ task: `Review: ${ch}`, mins: reviewMins, type: 'review' });
          });

          days.push({ label: dayLabel, blocks });
        }
      }

      // Output the day-wise plan
      days.forEach((d, i) => {
        const totalMins = d.blocks.reduce((s, b) => s + b.mins, 0);
        const isLast = i === days.length - 1;
        response += `**Day ${i + 1} — ${d.label}**${isLast ? ' 📝 (Final review)' : ''} (${formatMinutes(Math.round(totalMins))}):\n`;
        d.blocks.forEach((b) => {
          const icon = b.type === 'review' ? '🔄' : b.type === 'practice' ? '✏️' : '📖';
          response += `  ${icon} ${b.task} — ${formatMinutes(Math.round(b.mins))}\n`;
        });
        response += `\n`;
      });

      // Add tips
      response += `**Strategy tips:**\n`;
      response += `  • Study the hardest chapters first when your energy is highest\n`;
      response += `  • Use 25-min Pomodoro sessions with 5-min breaks (Focus Mode)\n`;
      response += `  • After each chapter, do a quick 5-min recall — write what you remember\n`;
      response += `  • Save the last day for full review + practice problems only\n`;
      response += `  • Get 7-8 hours of sleep every night — sleep consolidates memory\n\n`;

      // Check for exam-related assignments
      if (pending.length > 0) {
        const examRelated = pending.filter((a) => /exam|test|quiz|midterm|final/i.test(a.title));
        if (examRelated.length > 0) {
          response += `📋 **Your exam-related assignments:**\n`;
          examRelated.forEach((a) => {
            response += `  • ${a.title} — ${dueText(getDaysUntil(a.due_date))}\n`;
          });
          response += `\n`;
        }
      }

      response += `💡 Sleep is non-negotiable. A well-rested brain outperforms a sleep-deprived one that studied 2 extra hours. You've got this!`;

      return response;
    }

    // ── FOCUS TIPS ────────────────────────────────────
    case 'focus_tips': {
      let response = `Here are strategies to improve your focus:\n\n`;
      response += `**1. The Pomodoro Technique**\n`;
      response += `Study in 25-minute focused blocks, then take a 5-minute break. After 4 blocks, take a longer 15-30 minute break. This works because it creates urgency (the timer is ticking) and prevents burnout. You can use the Focus Mode in this app!\n\n`;
      response += `**2. Eliminate Digital Distractions**\n`;
      response += `Put your phone in another room or use Do Not Disturb mode. Close all browser tabs except what you need. Even having your phone visible reduces cognitive capacity by ~10%.\n\n`;
      response += `**3. The 2-Minute Rule**\n`;
      response += `If a task takes less than 2 minutes, do it immediately instead of adding it to your to-do list. This prevents small tasks from accumulating and creating mental clutter.\n\n`;
      response += `**4. Environment Design**\n`;
      response += `Study in the same place every day — your brain will associate that spot with focus. Keep it clean, well-lit, and at a comfortable temperature. Consider noise-canceling headphones or white noise.\n\n`;
      response += `**5. The 5-Minute Start**\n`;
      response += `When you feel resistance to starting, commit to just 5 minutes. Tell yourself you can stop after that. Usually, getting started is the hardest part — once you're going, momentum takes over.\n\n`;
      response += `💡 Use Focus Mode in this app — it has a built-in Pomodoro timer that saves your completed sessions automatically!`;
      return response;
    }

    // ── MOTIVATION ────────────────────────────────────
    case 'motivation': {
      const responses = [
        `It's completely normal to feel overwhelmed — you're juggling a lot. Here's what I suggest:\n\n1. **Breathe and zoom out** — You've completed ${completed.length} ${completed.length === 1 ? 'assignment' : 'assignments'} already. That's real, measurable progress. You can do this.\n\n2. **Pick one thing** — Don't look at the full list. Pick the single most urgent task and focus only on that. Momentum builds from small wins.\n\n3. **Use the 5-minute rule** — Commit to just 5 minutes of work. If you want to stop after that, you can. Usually, starting is the hardest part.\n\n4. **Take a real break** — Step away for 15 minutes. Walk, stretch, get water. A short reset can completely change your mental state.\n\nYou've got this. One step at a time. 💪`,
        `I hear you — it's a lot right now. Let me put things in perspective:\n\n1. **You're further than you think** — You've logged ${formatMinutes(sessions.reduce((s, sess) => s + sess.duration_minutes, 0))} of study time and completed ${completed.length} ${completed.length === 1 ? 'assignment' : 'assignments'}. That's not nothing.\n\n2. **Not everything is urgent** — ${overdue.length > 0 ? `You have ${overdue.length} overdue ${overdue.length === 1 ? 'item' : 'items'}, but` : 'You have no overdue items, and'} ${pending.length - overdue.length} ${pending.length - overdue.length === 1 ? 'task is' : 'tasks are'} still on track.\n\n3. **Start tiny** — Pick the smallest, easiest task on your list. Complete it. Feel the win. Then pick the next one.\n\n4. **Be kind to yourself** — Burnout comes from ignoring your limits. It's okay to study less today and come back stronger tomorrow.\n\nProgress, not perfection. 🌟`,
        `Feeling overwhelmed is a sign you care — that's actually a good thing. But let's channel it productively:\n\n1. **Do a brain dump** — Write down everything that's stressing you out. Seeing it on paper makes it manageable instead of a swirling cloud of anxiety.\n\n2. **Sort by what's truly urgent** — ${overdue.length > 0 ? `${overdue.length} ${overdue.length === 1 ? 'item is' : 'items are'} overdue — start there.` : 'Nothing is overdue — you have more time than it feels like.'}\n\n3. **One Pomodoro at a time** — Don't think about the whole semester. Think about the next 25 minutes. That's it.\n\n4. **Celebrate every win** — Finished a single problem? That counts. Wrote one paragraph? That counts too.\n\n5. **Ask for help if you need it** — Talk to a classmate, a TA, or a counselor. You don't have to do this alone.\n\nYou are capable of more than you think. 🚀`,
      ];
      return responses[Math.floor(Math.random() * responses.length)];
    }

    // ── CONCEPT EXPLANATION ───────────────────────────
    case 'concept_explanation': {
      const match = findConcept(query);
      if (match) {
        const { subject, entry } = match;
        let response = `📚 **${entry.topic}** (${subject})\n\n`;
        response += `**Definition:**\n${entry.definition}\n\n`;
        response += `**Key Points:**\n`;
        entry.keyPoints.forEach((point, i) => {
          response += `  ${i + 1}. ${point}\n`;
        });
        response += `\n**Example:**\n${entry.example}\n`;

        // Check if there are related concepts in the same subject
        const subjectKnowledge = conceptKnowledge.find((sk) => sk.subject === subject);
        if (subjectKnowledge && subjectKnowledge.concepts.length > 1) {
          const related = subjectKnowledge.concepts
            .filter((c) => c.topic !== entry.topic)
            .slice(0, 3)
            .map((c) => c.topic);
          if (related.length > 0) {
            response += `\n**Related topics in ${subject}:** ${related.join(', ')}\n`;
            response += `Ask me about any of these to learn more!`;
          }
        }

        return response;
      }

      // The concept was matched in scoreIntent but findConcept returned null —
      // this shouldn't happen, but handle gracefully
      return `I can explain concepts from these subjects: ${listSupportedSubjects().join(', ')}.\n\nTry asking "Explain DBMS concepts", "What is polymorphism in OOP?", or "Explain logic gates in Digital Techniques".`;
    }

    // ── SUBJECT INFO ──────────────────────────────────
    case 'subject_info': {
      if (subjects.length === 0) {
        return "You haven't added any subjects yet. Go to the Study Planner to add your subjects with weekly study goals — then I can help you track progress and balance your time across them.";
      }

      let response = `Here's an overview of your ${subjects.length} ${subjects.length === 1 ? 'subject' : 'subjects'}:\n\n`;
      const weekAgo = subDays(new Date(), 7);

      subjects.forEach((s) => {
        const weeklyMins = sessions
          .filter((sess) => sess.subject_id === s.id)
          .filter((sess) => new Date(sess.completed_at) >= weekAgo)
          .reduce((sum, sess) => sum + sess.duration_minutes, 0);
        const totalMins = sessions.filter((sess) => sess.subject_id === s.id).reduce((sum, sess) => sum + sess.duration_minutes, 0);
        const goalMins = s.goal_hours_per_week * 60;
        const pct = goalMins > 0 ? Math.round((weeklyMins / goalMins) * 100) : 0;
        const subjAssignments = pending.filter((a) => a.subject_id === s.id);
        const subjCompleted = completed.filter((a) => a.subject_id === s.id);

        response += `**${s.name}**\n`;
        response += `  • Weekly goal: ${formatMinutes(goalMins)}\n`;
        response += `  • This week: ${formatMinutes(weeklyMins)} (${pct}% of goal)\n`;
        response += `  • Total study time: ${formatMinutes(totalMins)}\n`;
        response += `  • Assignments: ${subjCompleted.length} completed, ${subjAssignments.length} pending\n`;
        if (subjAssignments.length > 0) {
          const next = subjAssignments.sort((a, b) => (getDaysUntil(a.due_date) ?? 999) - (getDaysUntil(b.due_date) ?? 999))[0];
          response += `  • Next due: ${next.title} — ${dueText(getDaysUntil(next.due_date))}\n`;
        }
        response += `\n`;
      });

      const behindCount = subjects.filter((s) => {
        const weeklyMins = sessions
          .filter((sess) => sess.subject_id === s.id)
          .filter((sess) => new Date(sess.completed_at) >= weekAgo)
          .reduce((sum, sess) => sum + sess.duration_minutes, 0);
        return weeklyMins < s.goal_hours_per_week * 60;
      }).length;

      if (behindCount > 0) {
        response += `⚠️ ${behindCount} ${behindCount === 1 ? 'subject is' : 'subjects are'} behind their weekly goal. Consider allocating more study time to these.`;
      } else {
        response += `✅ All subjects are on track to meet their weekly goals. Great work!`;
      }

      return response;
    }

    // ── POMODORO INFO ─────────────────────────────────
    case 'pomodoro_info': {
      return `The **Pomodoro Technique** is a time management method that breaks work into focused intervals:\n\n**How it works:**\n1. Set a timer for 25 minutes (one "Pomodoro")\n2. Work with full focus — no distractions\n3. When the timer rings, take a 5-minute break\n4. After 4 Pomodoros, take a longer 15-30 minute break\n\n**Why it works:**\n• The ticking timer creates a sense of urgency\n• Short breaks prevent mental fatigue\n• It's easier to start when you only commit to 25 minutes\n• Tracking completed Pomodoros gives you a measurable sense of progress\n\n**In this app:**\nYou can use the Focus Mode page — it has a built-in Pomodoro timer with a visual progress ring. Select a subject, hit Start, and your completed sessions are automatically saved to your study history. You can customize the focus and break durations in Settings.\n\n💡 Try it now: go to Focus Mode, pick a subject, and do one 25-minute session!`;
    }

    // ── HELP ──────────────────────────────────────────
    case 'help': {
      return `I'm your AI Study Assistant. Here's what I can help with:\n\n📋 **Plan your study time**\n  "What should I study today?" or "Plan my week"\n\n🎯 **Prioritize assignments**\n  "What's most urgent?" or "What should I do first?"\n\n📅 **Check deadlines**\n  "What's due soon?" or "What's overdue?"\n\n📊 **Track your progress**\n  "How much have I studied?" or "Give me a progress report"\n\n💡 **Study tips & techniques**\n  "Give me study tips" or "How do I study better?"\n\n📝 **Exam preparation**\n  "Help me prepare for my exam"\n\n🧠 **Focus & concentration**\n  "How do I stay focused?" or "I keep getting distracted"\n\n💪 **Motivation & stress**\n  "I'm feeling overwhelmed" or "I'm stressed"\n\n📚 **Subject overview**\n  "How are my subjects doing?"\n\n📖 **Concept explanations**\n  "Explain DBMS concepts" or "What is polymorphism in OOP?"\n  I can explain topics in: ${listSupportedSubjects().join(', ')}\n\n⏱️ **Pomodoro info**\n  "How does the Pomodoro technique work?"\n\nI analyze your real assignments, subjects, and study sessions to give you personalized recommendations. I also have a built-in knowledge base for academic concepts. Just ask me anything in natural language!`;
    }

    // ── FALLBACK ──────────────────────────────────────
    case 'fallback':
    default: {
      // First: check if this is a concept question we missed
      // (e.g. a topic name we know but without explicit "explain" keywords)
      const conceptMatch = findConcept(query);
      if (conceptMatch) {
        const { subject, entry } = conceptMatch;
        let response = `📚 **${entry.topic}** (${subject})\n\n`;
        response += `**Definition:**\n${entry.definition}\n\n`;
        response += `**Key Points:**\n`;
        entry.keyPoints.forEach((point, i) => {
          response += `  ${i + 1}. ${point}\n`;
        });
        response += `\n**Example:**\n${entry.example}\n`;

        const subjectKnowledge = conceptKnowledge.find((sk) => sk.subject === subject);
        if (subjectKnowledge && subjectKnowledge.concepts.length > 1) {
          const related = subjectKnowledge.concepts
            .filter((c) => c.topic !== entry.topic)
            .slice(0, 3)
            .map((c) => c.topic);
          if (related.length > 0) {
            response += `\n**Related topics in ${subject}:** ${related.join(', ')}\n`;
            response += `Ask me about any of these to learn more!`;
          }
        }
        return response;
      }

      // Second: check if the query looks like a concept/learning question
      // (contains words like "explain", "concept", "what is") but we don't have it
      const q = query.toLowerCase();
      const learningWords = ['explain', 'concept', 'what is', 'what are', 'define', 'definition', 'meaning of', 'describe', 'elaborate'];
      const looksLikeConceptQuestion = learningWords.some((w) => q.includes(w));

      if (looksLikeConceptQuestion) {
        return `I don't have that specific concept in my knowledge base yet, but I can explain topics from these subjects:\n\n  • **DBMS** — Normalization, ACID properties, SQL joins, indexing, ER models\n  • **OOP** — Encapsulation, Inheritance, Polymorphism, Abstraction\n  • **Data Structures** — Arrays, Linked Lists, Stacks, Queues, Trees, Graphs\n  • **C Programming** — Pointers, Memory management, Structures\n  • **C++** — STL, Templates, Constructors/Destructors\n  • **Digital Techniques** — Logic gates, Boolean algebra, Flip-flops, Number systems\n\nTry asking about one of these topics, e.g. "Explain normalization in DBMS" or "What is a pointer in C?"`;
      }

      // Third: check if the user might be asking about a specific assignment
      // — but ONLY if the query doesn't look like a concept question
      const mentionedAssignment = pending.find((a) => {
        const words = a.title.toLowerCase().split(/\s+/);
        return words.some((w) => w.length > 4 && q.includes(w));
      });

      if (mentionedAssignment) {
        let response = `It looks like you're asking about **${mentionedAssignment.title}**:\n\n`;
        response += `  • Subject: ${mentionedAssignment.subject?.name || 'No subject'}\n`;
        response += `  • Due: ${dueText(getDaysUntil(mentionedAssignment.due_date))}\n`;
        response += `  • Priority: ${mentionedAssignment.priority}\n`;
        response += `  • Status: ${mentionedAssignment.status}\n`;
        if (mentionedAssignment.description) {
          response += `  • Details: ${mentionedAssignment.description}\n`;
        }
        response += `\nWould you like help prioritizing this, or creating a study plan around it?`;
        return response;
      }

      // Context-aware fallback — use conversation history
      if (lastUserTurn) {
        const lastIntent = history.filter((t) => t.role === 'user' && t.intent).slice(-1)[0]?.intent;
        if (lastIntent === 'schedule_today' || lastIntent === 'schedule_week') {
          return `I'm not sure I understood that, but if you'd like me to adjust your study plan, try telling me how much time you have — for example, "I have 2 hours to study today" or "Plan my week". You can also ask about deadlines, priorities, or study tips.`;
        }
        if (lastIntent === 'prioritize') {
          return `I didn't quite catch that. If you want more detail on a specific assignment, try asking "What's due soon?" or "What should I do first?". I can also create a study schedule or give you study tips.`;
        }
        if (lastIntent === 'concept_explanation') {
          return `I don't have that specific topic yet, but I can explain concepts from: ${listSupportedSubjects().join(', ')}. Try asking about a specific topic like "What is normalization?" or "Explain pointers in C".`;
        }
      }

      return `I'm not sure I understood that, but I'm here to help! I can:\n\n• Plan your study schedule — "What should I study today?"\n• Prioritize your assignments — "What's most urgent?"\n• Check deadlines — "What's due soon?"\n• Show your progress — "How am I doing?"\n• Explain concepts — "Explain DBMS concepts" or "What is OOP?"\n• Give study tips — "Help me study better"\n• Help with motivation — "I'm feeling overwhelmed"\n\nI can explain topics in: ${listSupportedSubjects().join(', ')}\n\nTry asking me one of these, or just describe what you need in your own words!`;
    }
  }
}

function formatMinutes(mins: number): string {
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}
