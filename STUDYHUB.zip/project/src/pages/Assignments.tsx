import { useState, useMemo } from 'react';
import { Plus, Search, Edit2, Trash2, Check, Filter, CheckSquare, X, Calendar } from 'lucide-react';
import { useAssignments } from '@/hooks/useAssignments';
import { useSubjects } from '@/hooks/useSubjects';
import { useToast } from '@/context/ToastContext';
import { Card, Button, EmptyState, Loader } from '@/components/ui';
import { Modal } from '@/components/Modal';
import { formatDueDate, getDaysUntilDue, getPriorityColor, cn } from '@/lib/helpers';
import type { Assignment } from '@/lib/types';

interface AssignmentFormData {
  title: string;
  description: string;
  subject_id: string;
  due_date: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'completed';
}

const emptyForm: AssignmentFormData = {
  title: '',
  description: '',
  subject_id: '',
  due_date: '',
  priority: 'medium',
  status: 'pending',
};

export function Assignments() {
  const { assignments, loading, createAssignment, updateAssignment, deleteAssignment, toggleStatus } = useAssignments();
  const { subjects } = useSubjects();
  const { showToast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<AssignmentFormData>(emptyForm);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'completed'>('all');
  const [filterPriority, setFilterPriority] = useState<'all' | 'low' | 'medium' | 'high'>('all');
  const [filterSubject, setFilterSubject] = useState('all');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const filtered = useMemo(() => {
    return assignments.filter((a) => {
      if (search && !a.title.toLowerCase().includes(search.toLowerCase()) && !a.description.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterStatus !== 'all' && a.status !== filterStatus) return false;
      if (filterPriority !== 'all' && a.priority !== filterPriority) return false;
      if (filterSubject !== 'all' && a.subject_id !== filterSubject) return false;
      return true;
    });
  }, [assignments, search, filterStatus, filterPriority, filterSubject]);

  const openCreate = () => {
    setEditingId(null);
    setFormData({ ...emptyForm, subject_id: subjects[0]?.id || '' });
    setModalOpen(true);
  };

  const openEdit = (a: Assignment) => {
    setEditingId(a.id);
    setFormData({
      title: a.title,
      description: a.description,
      subject_id: a.subject_id || '',
      due_date: a.due_date || '',
      priority: a.priority,
      status: a.status,
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showToast('Please enter a title', 'error');
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        subject_id: formData.subject_id || null,
        due_date: formData.due_date || null,
        priority: formData.priority,
        status: formData.status,
      };
      if (editingId) {
        await updateAssignment(editingId, payload);
        showToast('Assignment updated successfully');
      } else {
        await createAssignment(payload);
        showToast('Assignment created successfully');
      }
      setModalOpen(false);
      setFormData(emptyForm);
    } catch {
      showToast('Failed to save assignment', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteAssignment(id);
      showToast('Assignment deleted');
      setConfirmDelete(null);
    } catch {
      showToast('Failed to delete assignment', 'error');
    }
  };

  const handleToggle = async (a: Assignment) => {
    try {
      await toggleStatus(a);
      showToast(a.status === 'pending' ? 'Assignment completed!' : 'Assignment marked as pending');
    } catch {
      showToast('Failed to update status', 'error');
    }
  };

  if (loading) return <Loader label="Loading assignments..." />;

  return (
    <div className="space-y-6 animate-[fadeIn_0.4s_ease-out]">
      {/* Toolbar */}
      <Card className="p-4">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search assignments..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 pl-10 pr-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40 focus:border-violet-500/40 transition-all"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as typeof filterStatus)}
              className="rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-3 py-2.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="completed">Completed</option>
            </select>
            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value as typeof filterPriority)}
              className="rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-3 py-2.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
            >
              <option value="all">All Priorities</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <select
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              className="rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-3 py-2.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
            >
              <option value="all">All Subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            <Button onClick={openCreate} size="md">
              <Plus className="h-4 w-4" /> Add Assignment
            </Button>
          </div>
        </div>
      </Card>

      {/* Results count */}
      <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
        <Filter className="h-4 w-4" />
        <span>{filtered.length} {filtered.length === 1 ? 'assignment' : 'assignments'} found</span>
      </div>

      {/* Assignment List */}
      {filtered.length === 0 ? (
        <Card className="p-6">
          <EmptyState
            icon={<CheckSquare className="h-7 w-7" />}
            title={assignments.length === 0 ? "No assignments yet" : "No matching assignments"}
            description={assignments.length === 0 ? "Create your first assignment to start tracking your tasks." : "Try adjusting your search or filters."}
            action={assignments.length === 0 ? <Button onClick={openCreate}><Plus className="h-4 w-4" /> Create Assignment</Button> : undefined}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((a) => {
            const pc = getPriorityColor(a.priority);
            const daysLeft = getDaysUntilDue(a.due_date);
            const isOverdue = daysLeft !== null && daysLeft < 0 && a.status === 'pending';
            return (
              <Card key={a.id} hover className="p-5 group animate-[slideUp_0.3s_ease-out]">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={cn('inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg', pc.bg, pc.text)}>
                      <span className={cn('h-1.5 w-1.5 rounded-full', pc.dot)} />
                      {a.priority}
                    </span>
                    {a.subject && (
                      <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300" style={{ borderLeft: `3px solid ${a.subject.color}` }}>
                        {a.subject.name}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => handleToggle(a)}
                    className={cn(
                      'flex h-7 w-7 items-center justify-center rounded-lg transition-all',
                      a.status === 'completed'
                        ? 'bg-emerald-500 text-white'
                        : 'border-2 border-slate-300 dark:border-white/20 text-transparent hover:border-emerald-500'
                    )}
                  >
                    <Check className="h-4 w-4" />
                  </button>
                </div>

                <h3 className={cn(
                  'font-display font-semibold text-slate-900 dark:text-white mb-1',
                  a.status === 'completed' && 'line-through text-slate-400 dark:text-slate-500'
                )}>
                  {a.title}
                </h3>
                {a.description && (
                  <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mb-3">{a.description}</p>
                )}

                <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-200/60 dark:border-white/5">
                  <div className="flex items-center gap-2">
                    <Calendar className={cn('h-4 w-4', isOverdue ? 'text-red-500' : 'text-slate-400')} />
                    <div>
                      <span className={cn('text-xs font-semibold', isOverdue ? 'text-red-500' : 'text-slate-600 dark:text-slate-300')}>
                        {formatDueDate(a.due_date)}
                      </span>
                      {daysLeft !== null && a.status === 'pending' && (
                        <span className={cn('text-[10px] block', isOverdue ? 'text-red-500' : 'text-slate-400')}>
                          {isOverdue ? `${Math.abs(daysLeft)}d overdue` : daysLeft === 0 ? 'Due today' : `${daysLeft}d left`}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEdit(a)}
                      className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-violet-500 dark:hover:bg-white/10 transition-colors"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setConfirmDelete(a.id)}
                      className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Create/Edit Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Assignment' : 'Create Assignment'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g. Calculus Problem Set 6"
              className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
              autoFocus
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Add details about this assignment..."
              rows={3}
              className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40 resize-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Subject</label>
              <select
                value={formData.subject_id}
                onChange={(e) => setFormData({ ...formData, subject_id: e.target.value })}
                className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
              >
                <option value="">No subject</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Due Date</label>
              <input
                type="date"
                value={formData.due_date}
                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                className="w-full rounded-xl border border-slate-200 dark:border-white/10 bg-white/50 dark:bg-white/5 px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Priority</label>
              <div className="flex gap-2">
                {(['low', 'medium', 'high'] as const).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setFormData({ ...formData, priority: p })}
                    className={cn(
                      'flex-1 rounded-xl px-3 py-2 text-xs font-semibold capitalize transition-all border',
                      formData.priority === p
                        ? cn(getPriorityColor(p).bg, getPriorityColor(p).text, getPriorityColor(p).border)
                        : 'border-slate-200 dark:border-white/10 text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5'
                    )}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1.5">Status</label>
              <div className="flex gap-2">
                {(['pending', 'completed'] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setFormData({ ...formData, status: s })}
                    className={cn(
                      'flex-1 rounded-xl px-3 py-2 text-xs font-semibold capitalize transition-all border',
                      formData.status === s
                        ? s === 'completed'
                          ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                          : 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                        : 'border-slate-200 dark:border-white/10 text-slate-400 hover:bg-slate-50 dark:hover:bg-white/5'
                    )}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <Button type="submit" disabled={submitting} className="flex-1">
              {submitting ? 'Saving...' : editingId ? 'Save Changes' : 'Create Assignment'}
            </Button>
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              <X className="h-4 w-4" /> Cancel
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Delete Assignment" className="max-w-md">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-300">Are you sure you want to delete this assignment? This action cannot be undone.</p>
          <div className="flex gap-3">
            <Button variant="danger" onClick={() => confirmDelete && handleDelete(confirmDelete)} className="flex-1">
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
            <Button variant="secondary" onClick={() => setConfirmDelete(null)}>Cancel</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
