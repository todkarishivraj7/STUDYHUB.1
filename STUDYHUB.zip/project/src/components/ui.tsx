import type { ReactNode } from 'react';
import { cn } from '@/lib/helpers';

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export function Card({ children, className, hover }: CardProps) {
  return (
    <div
      className={cn(
        'glass rounded-2xl shadow-sm',
        hover && 'transition-all duration-300 hover:shadow-lg hover:shadow-violet-500/5 hover:border-violet-500/20',
        className
      )}
    >
      {children}
    </div>
  );
}

interface StatCardProps {
  icon: ReactNode;
  label: string;
  value: string | number;
  trend?: string;
  trendUp?: boolean;
  color?: string;
}

export function StatCard({ icon, label, value, trend, trendUp, color = 'violet' }: StatCardProps) {
  const colorMap: Record<string, string> = {
    violet: 'from-violet-500/20 to-violet-500/5 text-violet-500',
    indigo: 'from-indigo-500/20 to-indigo-500/5 text-indigo-500',
    emerald: 'from-emerald-500/20 to-emerald-500/5 text-emerald-500',
    amber: 'from-amber-500/20 to-amber-500/5 text-amber-500',
    sky: 'from-sky-500/20 to-sky-500/5 text-sky-500',
    rose: 'from-rose-500/20 to-rose-500/5 text-rose-500',
  };

  return (
    <Card hover className="p-5 animate-[slideUp_0.4s_ease-out]">
      <div className="flex items-start justify-between">
        <div className={cn('flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br', colorMap[color])}>
          {icon}
        </div>
        {trend && (
          <span className={cn(
            'text-xs font-semibold px-2 py-1 rounded-lg',
            trendUp ? 'text-emerald-600 bg-emerald-500/10 dark:text-emerald-400' : 'text-slate-500 bg-slate-500/10'
          )}>
            {trend}
          </span>
        )}
      </div>
      <div className="mt-4">
        <p className="text-2xl font-bold font-display text-slate-900 dark:text-white">{value}</p>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">{label}</p>
      </div>
    </Card>
  );
}

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  type?: 'button' | 'submit';
  disabled?: boolean;
}

export function Button({ children, onClick, variant = 'primary', size = 'md', className, type = 'button', disabled }: ButtonProps) {
  const variants: Record<string, string> = {
    primary: 'bg-gradient-to-r from-violet-500 to-indigo-600 text-white shadow-lg shadow-violet-500/25 hover:shadow-violet-500/40 hover:brightness-110',
    secondary: 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-white/5 dark:text-slate-200 dark:hover:bg-white/10',
    ghost: 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/5',
    danger: 'bg-red-500/10 text-red-500 hover:bg-red-500/20 border border-red-500/20',
  };
  const sizes: Record<string, string> = {
    sm: 'px-3 py-1.5 text-xs rounded-lg gap-1.5',
    md: 'px-4 py-2.5 text-sm rounded-xl gap-2',
    lg: 'px-6 py-3 text-base rounded-xl gap-2.5',
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'inline-flex items-center justify-center font-semibold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed',
        variants[variant],
        sizes[size],
        className
      )}
    >
      {children}
    </button>
  );
}

interface EmptyStateProps {
  icon: ReactNode;
  title: string;
  description: string;
  action?: ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-[fadeIn_0.4s_ease-out]">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500/15 to-indigo-500/10 text-violet-500 mb-4">
        {icon}
      </div>
      <h3 className="font-display text-lg font-semibold text-slate-700 dark:text-slate-200">{title}</h3>
      <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-sm">{description}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Loader({ label = 'Loading...' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <div className="h-10 w-10 rounded-full border-3 border-violet-500/20 border-t-violet-500 animate-spin" />
      <p className="mt-4 text-sm text-slate-500 dark:text-slate-400">{label}</p>
    </div>
  );
}
