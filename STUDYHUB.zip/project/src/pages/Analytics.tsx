import { useMemo } from 'react';
import { TrendingUp, Clock, Target, Award, BookOpen } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend,
} from 'recharts';
import { useStudySessions } from '@/hooks/useStudySessions';
import { useSubjects } from '@/hooks/useSubjects';
import { useAssignments } from '@/hooks/useAssignments';
import { Card, Loader, StatCard, EmptyState } from '@/components/ui';
import { formatMinutes, cn } from '@/lib/helpers';
import { format, subDays, parseISO } from 'date-fns';

export function Analytics() {
  const { sessions, loading } = useStudySessions();
  const { subjects } = useSubjects();
  const { assignments } = useAssignments();

  const weeklyData = useMemo(() => {
    const days: { day: string; minutes: number; sessions: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const daySessions = sessions.filter((s) => format(parseISO(s.completed_at), 'yyyy-MM-dd') === dateStr);
      const minutes = daySessions.reduce((sum, s) => sum + s.duration_minutes, 0);
      days.push({ day: format(date, 'EEE'), minutes, sessions: daySessions.length });
    }
    return days;
  }, [sessions]);

  const subjectDistribution = useMemo(() => {
    return subjects.map((s) => {
      const minutes = sessions
        .filter((sess) => sess.subject_id === s.id)
        .reduce((sum, sess) => sum + sess.duration_minutes, 0);
      return { name: s.name, value: minutes, color: s.color };
    }).filter((s) => s.value > 0);
  }, [subjects, sessions]);

  const subjectProgress = useMemo(() => {
    return subjects.map((s) => {
      const weeklyMinutes = sessions
        .filter((sess) => sess.subject_id === s.id)
        .filter((sess) => {
          const days = Math.floor((Date.now() - new Date(sess.completed_at).getTime()) / (1000 * 60 * 60 * 24));
          return days <= 7;
        })
        .reduce((sum, sess) => sum + sess.duration_minutes, 0);
      const goalMinutes = s.goal_hours_per_week * 60;
      const progress = goalMinutes > 0 ? Math.round((weeklyMinutes / goalMinutes) * 100) : 0;
      return { name: s.name, progress: Math.min(100, progress), color: s.color, weeklyMinutes, goalMinutes };
    }).sort((a, b) => b.progress - a.progress);
  }, [subjects, sessions]);

  const assignmentStats = useMemo(() => {
    const total = assignments.length;
    const completed = assignments.filter((a) => a.status === 'completed').length;
    const pending = total - completed;
    const byPriority = {
      high: assignments.filter((a) => a.priority === 'high').length,
      medium: assignments.filter((a) => a.priority === 'medium').length,
      low: assignments.filter((a) => a.priority === 'low').length,
    };
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;
    return { total, completed, pending, byPriority, completionRate };
  }, [assignments]);

  const totalMinutes = sessions.reduce((sum, s) => sum + s.duration_minutes, 0);
  const weeklyMinutes = weeklyData.reduce((sum, d) => sum + d.minutes, 0);
  const avgDailyMinutes = Math.round(weeklyMinutes / 7);

  if (loading) return <Loader label="Loading analytics..." />;

  const hasData = sessions.length > 0 || assignments.length > 0;

  if (!hasData) {
    return (
      <Card className="p-6">
        <EmptyState
          icon={<TrendingUp className="h-7 w-7" />}
          title="No data to analyze yet"
          description="Complete study sessions and assignments to see your analytics here."
        />
      </Card>
    );
  }

  return (
    <div className="space-y-6 animate-[fadeIn_0.4s_ease-out]">
      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<Clock className="h-5 w-5" />} label="Total Study Time" value={formatMinutes(totalMinutes)} color="violet" />
        <StatCard icon={<TrendingUp className="h-5 w-5" />} label="This Week" value={formatMinutes(weeklyMinutes)} color="indigo" />
        <StatCard icon={<Target className="h-5 w-5" />} label="Daily Average" value={formatMinutes(avgDailyMinutes)} color="sky" />
        <StatCard icon={<Award className="h-5 w-5" />} label="Completion Rate" value={`${assignmentStats.completionRate}%`} color="emerald" />
      </div>

      {/* Weekly Study Chart */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">Weekly Study Time</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Minutes studied per day this week</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={weeklyData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#8b5cf6" stopOpacity={1} />
                <stop offset="100%" stopColor="#6366f1" stopOpacity={0.6} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.1)" vertical={false} />
            <XAxis dataKey="day" tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}m`} />
            <Tooltip
              contentStyle={{
                background: 'rgba(15,23,42,0.95)',
                border: '1px solid rgba(139,92,246,0.3)',
                borderRadius: '12px',
                color: '#e2e8f0',
                fontSize: '13px',
              }}
              cursor={{ fill: 'rgba(139,92,246,0.05)' }}
              formatter={(value) => [formatMinutes(Number(value)), 'Study Time']}
            />
            <Bar dataKey="minutes" fill="url(#barGradient)" radius={[8, 8, 0, 0]} maxBarSize={60} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Subject Distribution Pie */}
        <Card className="p-6">
          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-1">Subject Distribution</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Study time by subject</p>
          {subjectDistribution.length === 0 ? (
            <EmptyState icon={<BookOpen className="h-6 w-6" />} title="No data" description="Study sessions will appear here." />
          ) : (
            <>
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={subjectDistribution}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    innerRadius={50}
                    paddingAngle={3}
                  >
                    {subjectDistribution.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: 'rgba(15,23,42,0.95)',
                      border: '1px solid rgba(139,92,246,0.3)',
                      borderRadius: '12px',
                      color: '#e2e8f0',
                      fontSize: '13px',
                    }}
                    formatter={(value) => [formatMinutes(Number(value)), 'Study Time']}
                  />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    formatter={(value: string) => <span className="text-xs text-slate-600 dark:text-slate-300">{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            </>
          )}
        </Card>

        {/* Assignment Priority Distribution */}
        <Card className="p-6">
          <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-1">Assignment Overview</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Task breakdown by priority</p>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-xl bg-red-500/10 p-4 text-center">
                <p className="text-2xl font-bold text-red-500">{assignmentStats.byPriority.high}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">High Priority</p>
              </div>
              <div className="rounded-xl bg-amber-500/10 p-4 text-center">
                <p className="text-2xl font-bold text-amber-500">{assignmentStats.byPriority.medium}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Medium Priority</p>
              </div>
              <div className="rounded-xl bg-emerald-500/10 p-4 text-center">
                <p className="text-2xl font-bold text-emerald-500">{assignmentStats.byPriority.low}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Low Priority</p>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-slate-600 dark:text-slate-300 font-semibold">Completion Progress</span>
                <span className="text-violet-500 font-bold">{assignmentStats.completionRate}%</span>
              </div>
              <div className="h-3 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-500 to-indigo-600 transition-all duration-700"
                  style={{ width: `${assignmentStats.completionRate}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mt-2">
                <span>{assignmentStats.completed} completed</span>
                <span>{assignmentStats.pending} pending</span>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Subject Progress */}
      <Card className="p-6">
        <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-1">Subject-wise Progress</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-5">Weekly goal completion by subject</p>
        {subjectProgress.length === 0 ? (
          <EmptyState icon={<Target className="h-6 w-6" />} title="No subjects" description="Add subjects to track progress." />
        ) : (
          <div className="space-y-4">
            {subjectProgress.map((s) => (
              <div key={s.name}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: s.color }} />
                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{s.name}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-slate-500 dark:text-slate-400">{formatMinutes(s.weeklyMinutes)} / {formatMinutes(s.goalMinutes)}</span>
                    <span className={cn(
                      'font-bold',
                      s.progress >= 100 ? 'text-emerald-500' : s.progress >= 50 ? 'text-violet-500' : 'text-amber-500'
                    )}>{s.progress}%</span>
                  </div>
                </div>
                <div className="h-2.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${s.progress}%`, backgroundColor: s.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
