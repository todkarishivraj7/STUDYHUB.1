import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Subject, SubjectInput } from '@/lib/types';

export function useSubjects() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchSubjects = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('subjects').select('*').order('name');
    if (error) {
      console.error('Error fetching subjects:', error);
    } else {
      setSubjects(data as Subject[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchSubjects(); }, [fetchSubjects]);

  const createSubject = async (input: SubjectInput) => {
    const { data, error } = await supabase.from('subjects').insert(input).select('*').single();
    if (error) throw error;
    setSubjects((prev) => [...prev, data as Subject].sort((a, b) => a.name.localeCompare(b.name)));
    return data;
  };

  const updateSubject = async (id: string, updates: Partial<SubjectInput>) => {
    const { data, error } = await supabase.from('subjects').update(updates).eq('id', id).select('*').single();
    if (error) throw error;
    setSubjects((prev) => prev.map((s) => (s.id === id ? data as Subject : s)));
    return data;
  };

  const deleteSubject = async (id: string) => {
    const { error } = await supabase.from('subjects').delete().eq('id', id);
    if (error) throw error;
    setSubjects((prev) => prev.filter((s) => s.id !== id));
  };

  return { subjects, loading, createSubject, updateSubject, deleteSubject, refetch: fetchSubjects };
}
