export interface ConceptEntry {
  topic: string;
  aliases: string[];
  definition: string;
  keyPoints: string[];
  example: string;
}

export interface SubjectKnowledge {
  subject: string;
  aliases: string[];
  concepts: ConceptEntry[];
}

export const conceptKnowledge: SubjectKnowledge[] = [
  {
    subject: 'DBMS',
    aliases: ['dbms', 'database', 'database management', 'database management system', 'sql', 'rdbms'],
    concepts: [
      {
        topic: 'DBMS (Database Management System)',
        aliases: ['dbms', 'database management system', 'what is dbms'],
        definition: 'A Database Management System (DBMS) is software that lets you create, store, modify, and retrieve data in a structured way. Think of it as a digital filing cabinet where data is organized into tables so you can find and update it efficiently.',
        keyPoints: [
          'Stores data in tables (rows and columns) for the Relational model',
          'Provides ACID properties: Atomicity, Consistency, Isolation, Durability',
          'Supports SQL (Structured Query Language) for querying and manipulating data',
          'Handles concurrency — multiple users can access data simultaneously',
          'Enforces data integrity through constraints (primary key, foreign key, etc.)',
        ],
        example: 'MySQL, PostgreSQL, Oracle, and SQLite are all DBMS examples. When you log into a website, your username and password are looked up in a database table using a DBMS.',
      },
      {
        topic: 'Normalization',
        aliases: ['normalization', 'normal form', '1nf', '2nf', '3nf', 'bcnf'],
        definition: 'Normalization is the process of organizing data in a database to reduce redundancy (duplicate data) and improve data integrity. It involves splitting large tables into smaller, related tables and linking them with relationships.',
        keyPoints: [
          '1NF: Each cell has a single value, no repeating groups',
          '2NF: Meets 1NF + all non-key attributes depend on the entire primary key',
          '3NF: Meets 2NF + no transitive dependencies (non-key attributes depend only on the primary key)',
          'BCNF: A stricter version of 3NF where every determinant is a candidate key',
          'Reduces data duplication and update anomalies',
        ],
        example: 'Instead of storing a customer\'s address in every order row, you store it once in a Customers table and reference it by customer_id in the Orders table.',
      },
      {
        topic: 'ACID Properties',
        aliases: ['acid', 'acid properties', 'atomicity', 'consistency', 'isolation', 'durability'],
        definition: 'ACID is a set of four properties that guarantee database transactions are processed reliably, even if the system crashes or multiple users access data at the same time.',
        keyPoints: [
          'Atomicity — A transaction is "all or nothing": either all operations succeed, or none do',
          'Consistency — A transaction moves the database from one valid state to another',
          'Isolation — Concurrent transactions don\'t interfere with each other',
          'Durability — Once a transaction is committed, it survives system crashes',
        ],
        example: 'When you transfer money from Account A to Account B, atomicity ensures that if the deduction from A succeeds but the credit to B fails, the entire transaction is rolled back — no money disappears.',
      },
      {
        topic: 'SQL Joins',
        aliases: ['join', 'joins', 'inner join', 'left join', 'right join', 'outer join', 'sql join'],
        definition: 'A JOIN combines rows from two or more tables based on a related column between them (usually a foreign key). It lets you retrieve data that spans multiple tables in a single query.',
        keyPoints: [
          'INNER JOIN: Returns only matching rows from both tables',
          'LEFT JOIN: Returns all rows from the left table + matching rows from the right',
          'RIGHT JOIN: Returns all rows from the right table + matching rows from the left',
          'FULL OUTER JOIN: Returns all rows from both tables, matching where possible',
          'Joins use ON to specify the matching condition',
        ],
        example: 'SELECT students.name, grades.score FROM students INNER JOIN grades ON students.id = grades.student_id — this gives you each student\'s name alongside their scores.',
      },
      {
        topic: 'Indexing',
        aliases: ['index', 'indexing', 'database index', 'b-tree index'],
        definition: 'An index is a data structure (usually a B-tree) that speeds up data retrieval. It works like a book\'s index — instead of scanning every page, you look up the index to find the exact page directly.',
        keyPoints: [
          'Dramatically speeds up SELECT queries with WHERE clauses',
          'Slows down INSERT, UPDATE, and DELETE (the index must be updated too)',
          'Primary keys are automatically indexed',
          'Too many indexes waste space and slow down writes',
        ],
        example: 'Without an index, finding a student by roll number in a table of 1 million rows requires scanning all 1 million rows. With an index, it takes just a few steps — like finding a name in a phone book.',
      },
      {
        topic: 'Entity-Relationship (ER) Model',
        aliases: ['er model', 'er diagram', 'entity relationship', 'erd'],
        definition: 'The ER Model is a visual way to design a database before building it. It uses entities (things/objects), attributes (properties of entities), and relationships (how entities connect) to map out the database structure.',
        keyPoints: [
          'Entity: A real-world object (e.g., Student, Course) represented as a rectangle',
          'Attribute: A property of an entity (e.g., name, age) represented as an oval',
          'Relationship: An association between entities (e.g., Student enrolls in Course) represented as a diamond',
          'Cardinality: 1:1, 1:N, or N:N describes how many entities participate',
        ],
        example: 'An ER diagram for a school might show a Student entity with attributes (name, roll_no) connected to a Course entity with a "enrolls in" relationship of cardinality N:N — a student can take many courses, and a course can have many students.',
      },
    ],
  },
  {
    subject: 'OOP',
    aliases: ['oop', 'object oriented', 'object oriented programming', 'object-oriented'],
    concepts: [
      {
        topic: 'OOP (Object-Oriented Programming)',
        aliases: ['oop', 'object oriented programming', 'what is oop'],
        definition: 'Object-Oriented Programming is a programming paradigm that organizes code around "objects" — bundles of data (attributes) and behavior (methods). Instead of writing a long sequence of instructions, you model real-world entities as objects that interact with each other.',
        keyPoints: [
          'Four pillars: Encapsulation, Inheritance, Polymorphism, Abstraction',
          'Class is a blueprint; Object is an instance of a class',
          'Promotes code reuse, modularity, and maintainability',
          'Used in Java, C++, Python, C#, and many modern languages',
        ],
        example: 'A "Car" class has attributes (color, speed) and methods (start, brake). A specific car like "my red Toyota" is an object created from that class.',
      },
      {
        topic: 'Encapsulation',
        aliases: ['encapsulation', 'data hiding', 'encapsulate'],
        definition: 'Encapsulation is the practice of bundling data and the methods that operate on that data into a single unit (a class), and restricting direct access to some of the object\'s components. This protects data from being modified unexpectedly.',
        keyPoints: [
          'Achieved using access modifiers: public, private, protected',
          'Private data can only be accessed through public methods (getters/setters)',
          'Prevents external code from changing internal state directly',
          'Also called "data hiding"',
        ],
        example: 'A BankAccount class has a private "balance" variable. You can\'t change it directly (account.balance = 0). Instead, you call account.deposit(100) which validates the amount before updating balance.',
      },
      {
        topic: 'Inheritance',
        aliases: ['inheritance', 'inherit', 'parent class', 'child class', 'subclass'],
        definition: 'Inheritance allows a new class (child/subclass) to inherit attributes and methods from an existing class (parent/superclass). This promotes code reuse — you write common code once in the parent and extend it in children.',
        keyPoints: [
          'Child class gets all public/protected members of the parent',
          'Child can add new members or override parent methods',
          'Types: Single, Multiple, Multilevel, Hierarchical, Hybrid',
          'Java and C# use "extends" / ":" for inheritance; C++ uses ":"',
        ],
        example: 'A "Vehicle" class has speed and move(). A "Bicycle" class inherits from Vehicle — it automatically gets speed and move(), and can add its own method like pedal().',
      },
      {
        topic: 'Polymorphism',
        aliases: ['polymorphism', 'overloading', 'overriding', 'polymorphic'],
        definition: 'Polymorphism means "many forms" — the same function name or operator can behave differently depending on the context. It lets you write flexible code that works with objects of different types through a common interface.',
        keyPoints: [
          'Compile-time polymorphism: Method overloading (same name, different parameters)',
          'Runtime polymorphism: Method overriding (child class redefines a parent method)',
          'Achieved through virtual functions (C++) or dynamic dispatch (Java)',
          'Enables code to call the right method based on the actual object type at runtime',
        ],
        example: 'A "Shape" class has a method area(). Circle and Square both inherit from Shape and override area() with their own formula. You can loop through a list of Shapes and call area() — each one calculates correctly based on its actual type.',
      },
      {
        topic: 'Abstraction',
        aliases: ['abstraction', 'abstract class', 'abstract method', 'interface'],
        definition: 'Abstraction means showing only essential features and hiding internal implementation details. It lets you focus on what an object does rather than how it does it, reducing complexity.',
        keyPoints: [
          'Achieved through abstract classes and interfaces',
          'Abstract class: Cannot be instantiated, may contain abstract methods (no body)',
          'Interface: A pure contract — only method signatures, no implementation',
          'Subclasses must implement all abstract methods',
        ],
        example: 'When you drive a car, you use the steering wheel and pedals (interface) without knowing how the engine works internally. Similarly, an abstract "Payment" class defines a pay() method — PayPal and Stripe subclasses each implement pay() differently, but the calling code just calls payment.pay().',
      },
    ],
  },
  {
    subject: 'Data Structures',
    aliases: ['data structure', 'data structures', 'dsa', 'ds', 'algorithm'],
    concepts: [
      {
        topic: 'Data Structures',
        aliases: ['data structure', 'what is data structure', 'dsa'],
        definition: 'A data structure is a way of organizing and storing data in a computer so it can be accessed and modified efficiently. Choosing the right data structure for a problem is one of the most important skills in programming.',
        keyPoints: [
          'Linear structures: Arrays, Linked Lists, Stacks, Queues',
          'Non-linear structures: Trees, Graphs, Heaps',
          'Hash-based: Hash Tables / Hash Maps',
          'The right choice depends on what operations you need most (insert, search, delete)',
        ],
        example: 'If you need fast lookups by key, use a Hash Table (O(1) average). If you need ordered data with fast insertions at both ends, use a Linked List or Deque.',
      },
      {
        topic: 'Arrays',
        aliases: ['array', 'arrays', 'list'],
        definition: 'An array is a collection of elements stored at contiguous memory locations, accessed by an index. It is the simplest and most widely used data structure.',
        keyPoints: [
          'Elements are accessed by index in O(1) time',
          'Fixed size in most languages (C, Java); dynamic in Python, JS',
          'Inserting/deleting in the middle is O(n) — elements must shift',
          'Memory is allocated contiguously, so cache performance is excellent',
        ],
        example: 'scores = [85, 92, 78, 90]. To get the third score: scores[2] returns 78. To insert at the beginning, every element must shift right — that\'s O(n).',
      },
      {
        topic: 'Linked Lists',
        aliases: ['linked list', 'linkedlist', 'singly linked', 'doubly linked', 'node'],
        definition: 'A linked list is a linear data structure where elements (nodes) are connected by pointers. Each node contains data and a reference to the next node. Unlike arrays, nodes are not stored in contiguous memory.',
        keyPoints: [
          'Dynamic size — grows and shrinks at runtime',
          'Insertion/deletion at the beginning is O(1)',
          'Random access is O(n) — you must traverse from the head',
          'Types: Singly linked (next only), Doubly linked (next + prev), Circular',
        ],
        example: 'Think of a treasure hunt: each clue tells you where the next clue is. You can\'t jump to clue #5 directly — you must follow the chain from clue #1.',
      },
      {
        topic: 'Stacks',
        aliases: ['stack', 'lifo', 'push pop'],
        definition: 'A stack is a linear data structure that follows the Last-In-First-Out (LIFO) principle — the last element added is the first one removed. Think of a stack of plates: you add and remove from the top.',
        keyPoints: [
          'Push (add) and Pop (remove) are both O(1)',
          'Peek: Look at the top element without removing it',
          'Used in function call management, undo/redo, expression evaluation',
          'Can be implemented with arrays or linked lists',
        ],
        example: 'When you call a function, the return address is pushed onto the call stack. When the function returns, it\'s popped off — the most recent call returns first.',
      },
      {
        topic: 'Queues',
        aliases: ['queue', 'fifo', 'enqueue dequeue'],
        definition: 'A queue is a linear data structure that follows the First-In-First-Out (FIFO) principle — the first element added is the first one removed. Think of a line at a ticket counter.',
        keyPoints: [
          'Enqueue (add to rear) and Dequeue (remove from front) are O(1)',
          'Types: Simple queue, Circular queue, Priority queue, Deque (double-ended)',
          'Used in BFS, scheduling, buffering, and printer queues',
        ],
        example: 'In a print queue, the first document sent to the printer prints first. A priority queue would print urgent documents before others regardless of order.',
      },
      {
        topic: 'Trees',
        aliases: ['tree', 'binary tree', 'bst', 'binary search tree', 'avl', 'heap'],
        definition: 'A tree is a hierarchical data structure with a root node at the top and child nodes branching below. Each node has at most one parent but can have multiple children. There are no cycles.',
        keyPoints: [
          'Binary Tree: Each node has at most 2 children (left and right)',
          'BST (Binary Search Tree): Left child < parent < right child — enables O(log n) search',
          'AVL Tree: A self-balancing BST that keeps height minimal',
          'Heap: A complete binary tree used for priority queues (min-heap, max-heap)',
          'Traversals: Inorder, Preorder, Postorder, Level-order (BFS)',
        ],
        example: 'A file system is a tree: the root directory is at the top, folders are branches, and files are leaves. A BST lets you search for a value by going left (smaller) or right (larger) at each step.',
      },
      {
        topic: 'Graphs',
        aliases: ['graph', 'bfs', 'dfs', 'adjacency list', 'adjacency matrix'],
        definition: 'A graph is a non-linear data structure consisting of vertices (nodes) connected by edges. Graphs model relationships — social networks, maps, and dependency chains are all graphs.',
        keyPoints: [
          'Directed: edges have direction; Undirected: edges go both ways',
          'Represented via Adjacency Matrix (2D array) or Adjacency List (array of lists)',
          'BFS (Breadth-First Search): explores level by level using a queue',
          'DFS (Depth-First Search): explores as far as possible using recursion/stack',
          'Used in shortest path, network flow, topological sorting',
        ],
        example: 'Google Maps uses a graph where intersections are vertices and roads are edges. BFS/DFS algorithms find routes; Dijkstra\'s algorithm finds the shortest path.',
      },
    ],
  },
  {
    subject: 'C Programming',
    aliases: ['c programming', 'c language', 'c lang', 'c code'],
    concepts: [
      {
        topic: 'C Programming Language',
        aliases: ['c programming', 'what is c', 'c language'],
        definition: 'C is a general-purpose, compiled, procedural programming language developed by Dennis Ritchie in 1972. It is low-level enough to interact closely with hardware but high-level enough to be readable. It is the foundation for C++, Java, and many other languages.',
        keyPoints: [
          'Procedural — code is organized into functions',
          'Compiled — source code is converted to machine code before execution',
          'Statically typed — variable types are checked at compile time',
          'Provides low-level memory access via pointers',
          'Fast and efficient — widely used in OS development, embedded systems',
        ],
        example: '#include <stdio.h>\nint main() {\n  printf("Hello, World!\\n");\n  return 0;\n}',
      },
      {
        topic: 'Pointers',
        aliases: ['pointer', 'pointers', 'memory address', 'dereference'],
        definition: 'A pointer is a variable that stores the memory address of another variable. Instead of holding a value directly, it holds "where the value lives in memory." Pointers are C\'s most powerful and dangerous feature.',
        keyPoints: [
          'Declared with * : int *ptr means ptr points to an int',
          '& (address-of) gets the address of a variable',
          '* (dereference) gets the value at the address a pointer holds',
          'NULL pointer: points to nothing — dereferencing it crashes the program',
          'Used for dynamic memory (malloc/free), arrays, and passing by reference',
        ],
        example: 'int x = 10; int *ptr = &x; — ptr now holds the address of x. *ptr gives you 10. Change *ptr = 20 and x becomes 20 too.',
      },
      {
        topic: 'Memory Management',
        aliases: ['memory management', 'malloc', 'calloc', 'free', 'dynamic memory', 'heap memory'],
        definition: 'C requires manual memory management. You allocate memory on the heap using malloc/calloc when you need it at runtime, and you must free it when done. Forgetting to free causes memory leaks.',
        keyPoints: [
          'malloc(size): allocates uninitialized memory, returns void*',
          'calloc(n, size): allocates and zeroes memory for n elements',
          'realloc(ptr, size): resizes previously allocated memory',
          'free(ptr): releases memory back to the system — must be called for every malloc',
          'Stack memory (local variables) is auto-managed; heap memory is manual',
        ],
        example: 'int *arr = malloc(5 * sizeof(int)); — allocates space for 5 integers. After use: free(arr); — without this, the memory leaks.',
      },
      {
        topic: 'Structures',
        aliases: ['struct', 'structure', 'structures'],
        definition: 'A struct is a user-defined data type that groups related variables of different types under one name. It lets you represent a real-world entity with multiple attributes.',
        keyPoints: [
          'Defined with the struct keyword',
          'Members are accessed with the dot (.) operator, or -> with pointers',
          'Can contain any data types: int, float, char, arrays, even other structs',
          'Memory is the sum of all member sizes (plus possible padding)',
        ],
        example: 'struct Student { char name[50]; int roll; float gpa; }; creates a Student type. struct Student s1 = {"Alice", 42, 3.8}; — access s1.name, s1.roll.',
      },
    ],
  },
  {
    subject: 'C++',
    aliases: ['c++', 'cpp', 'c plus plus'],
    concepts: [
      {
        topic: 'C++ Programming Language',
        aliases: ['c++', 'cpp', 'what is c++', 'c plus plus'],
        definition: 'C++ is an extension of C that adds object-oriented programming features (classes, inheritance, polymorphism) along with templates, exceptions, and a rich standard library. It was created by Bjarne Stroustrup in 1985 as "C with Classes."',
        keyPoints: [
          'Multi-paradigm: supports procedural, OOP, and generic programming',
          'Backward compatible with C',
          'Provides the STL (Standard Template Library) with ready-made containers and algorithms',
          'Supports templates for generic programming (write once, use for any type)',
          'Compiled, statically typed, and high-performance',
        ],
        example: '#include <iostream>\nint main() {\n  std::cout << "Hello, World!" << std::endl;\n  return 0;\n}',
      },
      {
        topic: 'STL (Standard Template Library)',
        aliases: ['stl', 'standard template library', 'vector', 'map', 'set'],
        definition: 'The STL is a powerful set of C++ template classes and functions that provide general-purpose data structures (containers) and algorithms. It saves you from implementing common structures from scratch.',
        keyPoints: [
          'Containers: vector (dynamic array), list, map, set, stack, queue',
          'Algorithms: sort, find, reverse, accumulate, binary_search',
          'Iterators: objects that point to elements, used to traverse containers',
          'Functors: objects that act like functions (overload operator())',
          'All STL is templated — works with any data type',
        ],
        example: 'vector<int> v = {3, 1, 4, 1, 5}; sort(v.begin(), v.end()); — sorts the vector in ascending order. No need to write your own sort.',
      },
      {
        topic: 'Templates',
        aliases: ['template', 'templates', 'generic programming', 'template function'],
        definition: 'Templates allow you to write a single function or class that works with any data type. The compiler generates the appropriate version for each type you use. This is C++\'s approach to generic programming.',
        keyPoints: [
          'Function templates: template <typename T> T max(T a, T b)',
          'Class templates: template <typename T> class Stack { ... }',
          'Compiler generates type-specific code at compile time',
          'Avoids code duplication — write once, use for int, float, string, custom types',
        ],
        example: 'template <typename T> T maxVal(T a, T b) { return (a > b) ? a : b; } — call maxVal(3, 7) for ints, maxVal(3.14, 2.71) for doubles. Same code, different types.',
      },
      {
        topic: 'Constructors and Destructors',
        aliases: ['constructor', 'destructor', 'copy constructor', 'default constructor'],
        definition: 'A constructor is a special method that runs automatically when an object is created, initializing its state. A destructor runs when an object is destroyed, cleaning up resources. Both have the same name as the class.',
        keyPoints: [
          'Default constructor: no parameters, called automatically on object creation',
          'Parameterized constructor: accepts arguments to initialize with specific values',
          'Copy constructor: creates a new object as a copy of an existing one',
          'Destructor: prefixed with ~, called automatically when object goes out of scope',
          'If you don\'t define them, C++ provides default versions',
        ],
        example: 'class Car { public: Car() { cout << "Created"; } ~Car() { cout << "Destroyed"; } }; — when you create Car c;, "Created" prints. When c goes out of scope, "Destroyed" prints.',
      },
    ],
  },
  {
    subject: 'Digital Techniques',
    aliases: ['digital techniques', 'digital electronics', 'digital logic', 'boolean', 'logic gates', 'flip flop'],
    concepts: [
      {
        topic: 'Digital Electronics',
        aliases: ['digital electronics', 'digital techniques', 'what is digital electronics', 'digital logic'],
        definition: 'Digital electronics deals with circuits that operate on discrete voltage levels — typically 0 (LOW/OFF) and 1 (HIGH/ON). It is the foundation of all modern computers and digital devices.',
        keyPoints: [
          'Uses binary number system (0 and 1)',
          'Logic levels: 0V = logic 0, 5V/3.3V = logic 1',
          'Built from logic gates: AND, OR, NOT, NAND, NOR, XOR, XNOR',
          'Combinational circuits: output depends only on current inputs',
          'Sequential circuits: output depends on current inputs + past state (memory)',
        ],
        example: 'A light switch is a simple digital system — it\'s either ON (1) or OFF (0). A computer is a massive collection of such switches (transistors) processing binary data.',
      },
      {
        topic: 'Logic Gates',
        aliases: ['logic gate', 'logic gates', 'and gate', 'or gate', 'not gate', 'nand', 'nor', 'xor'],
        definition: 'Logic gates are the building blocks of digital circuits. Each gate takes one or more binary inputs and produces a binary output based on a specific logical rule.',
        keyPoints: [
          'AND: Output is 1 only if ALL inputs are 1',
          'OR: Output is 1 if ANY input is 1',
          'NOT: Inverts the input (1→0, 0→1)',
          'NAND: AND + NOT — universal gate, can build any other gate',
          'NOR: OR + NOT — also a universal gate',
          'XOR: Output is 1 if inputs are different',
        ],
        example: 'AND gate: if input A=1 and B=1, output=1. If either is 0, output=0. This is like a door that needs two keys turned at the same time to open.',
      },
      {
        topic: 'Boolean Algebra',
        aliases: ['boolean algebra', 'boolean', 'boolean expression', 'kmap', 'k-map', 'karnaugh map'],
        definition: 'Boolean algebra is the mathematics of logic — it uses variables that can only be 0 or 1, and operations AND (·), OR (+), and NOT (\'). It is used to simplify digital circuits.',
        keyPoints: [
          'DeMorgan\'s Laws: NOT(A AND B) = NOT A OR NOT B; NOT(A OR B) = NOT A AND NOT B',
          'A + 0 = A, A · 1 = A, A + 1 = 1, A · 0 = 0',
          'A + A\' = 1 (complement), A · A\' = 0',
          'Karnaugh Maps (K-Maps): A visual method to simplify Boolean expressions',
          'Simplification reduces the number of gates needed in a circuit',
        ],
        example: 'Expression: A·B + A·B\' can be simplified to A·(B + B\') = A·1 = A. This means instead of two AND gates and an OR gate, you just need a wire carrying A.',
      },
      {
        topic: 'Flip-Flops',
        aliases: ['flip flop', 'flipflop', 'sr latch', 'jk flip flop', 'd flip flop', 't flip flop'],
        definition: 'A flip-flop is a basic memory element in digital electronics that can store one bit of data (0 or 1). It has two stable states and can change state when triggered by a clock signal.',
        keyPoints: [
          'SR Flip-Flop: Set (S) and Reset (R) inputs — S=1 sets to 1, R=1 resets to 0',
          'JK Flip-Flop: Like SR but resolves the invalid state — J=K=1 toggles',
          'D Flip-Flop: Data input — output follows D on clock edge (used in registers)',
          'T Flip-Flop: Toggles output on each clock pulse if T=1 (used in counters)',
          'Edge-triggered: state changes only on clock rising or falling edge',
        ],
        example: 'A D flip-flop in a register stores one bit of data. Connect 8 D flip-flops together and you have an 8-bit register that can store a byte.',
      },
      {
        topic: 'Number Systems',
        aliases: ['number system', 'binary', 'hexadecimal', 'octal', 'decimal', 'number conversion'],
        definition: 'Digital electronics uses different number systems to represent data. The most common are binary (base 2), octal (base 8), decimal (base 10), and hexadecimal (base 16).',
        keyPoints: [
          'Binary (base 2): digits 0-1, e.g., 1010 = 10 in decimal',
          'Octal (base 8): digits 0-7, e.g., 12 = 10 in decimal',
          'Decimal (base 10): digits 0-9, our everyday system',
          'Hexadecimal (base 16): digits 0-9 and A-F, e.g., A = 10, FF = 255',
          'Conversions: binary→hex groups 4 bits, binary→octal groups 3 bits',
        ],
        example: 'The binary number 1101 = 1×8 + 1×4 + 0×2 + 1×1 = 13 in decimal. In hex, 1101 = D. Memory addresses in computers are often shown in hex (e.g., 0xFF).',
      },
    ],
  },
];

// Build a flat searchable index of all concepts
interface IndexedConcept {
  subject: string;
  entry: ConceptEntry;
}

const conceptIndex: IndexedConcept[] = conceptKnowledge.flatMap((sk) =>
  sk.concepts.map((entry) => ({ subject: sk.subject, entry }))
);

export function findConcept(query: string): { subject: string; entry: ConceptEntry } | null {
  const q = query.toLowerCase().trim();

  // First try exact topic match
  for (const ic of conceptIndex) {
    if (q.includes(ic.entry.topic.toLowerCase())) {
      return ic;
    }
  }

  // Try alias matches — longest alias first for specificity
  const allAliases = conceptIndex
    .flatMap((ic) => ic.entry.aliases.map((a) => ({ alias: a, ic })))
    .sort((a, b) => b.alias.length - a.alias.length);

  for (const { alias, ic } of allAliases) {
    if (q.includes(alias)) {
      return ic;
    }
  }

  // Try subject-level match — return an overview if subject is mentioned but no specific concept
  for (const sk of conceptKnowledge) {
    for (const alias of sk.aliases) {
      if (q.includes(alias)) {
        // Return the first concept (usually the overview) of that subject
        return { subject: sk.subject, entry: sk.concepts[0] };
      }
    }
  }

  return null;
}

export function getSubjectOverview(subjectName: string): SubjectKnowledge | null {
  return conceptKnowledge.find((sk) =>
    sk.aliases.some((a) => subjectName.toLowerCase().includes(a))
  ) || null;
}

export function listSupportedSubjects(): string[] {
  return conceptKnowledge.map((sk) => sk.subject);
}
