import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { UserPreferences } from '@/lib/types';
import { supabase } from '@/lib/supabase';

interface ThemeContextValue {
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  prefs: UserPreferences | null;
  updatePrefs: (updates: Partial<UserPreferences>) => Promise<void>;
  loadingPrefs: boolean;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

const defaultPrefs: UserPreferences = {
  id: '',
  theme: 'dark',
  daily_study_goal: 120,
  pomodoro_focus: 25,
  pomodoro_break: 5,
  student_name: 'Student',
};

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [prefs, setPrefs] = useState<UserPreferences | null>(null);
  const [loadingPrefs, setLoadingPrefs] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data } = await supabase.from('user_preferences').select('*').limit(1).maybeSingle();
      if (!mounted) return;
      if (data) {
        setPrefs(data as UserPreferences);
        setTheme(data.theme);
      } else {
        setPrefs(defaultPrefs);
      }
      setLoadingPrefs(false);
    })();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    if (prefs) {
      updatePrefs({ theme: next });
    }
  };

  const updatePrefs = async (updates: Partial<UserPreferences>) => {
    if (!prefs) return;
    const updated = { ...prefs, ...updates };
    setPrefs(updated);
    if (prefs.id) {
      await supabase.from('user_preferences').update(updates).eq('id', prefs.id);
    } else {
      const { data } = await supabase.from('user_preferences').insert(updated).select().single();
      if (data) setPrefs(data as UserPreferences);
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, prefs, updatePrefs, loadingPrefs }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
