import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { StudySession } from '@/lib/types';

export function useStudySessions() {
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchSessions = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('study_sessions')
      .select('*, subject:subjects(*)')
      .order('completed_at', { ascending: false });
    if (error) {
      console.error('Error fetching sessions:', error);
    } else {
      setSessions(data as StudySession[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchSessions(); }, [fetchSessions]);

  const createSession = async (subjectId: string | null, durationMinutes: number, sessionType: string = 'pomodoro') => {
    const { data, error } = await supabase
      .from('study_sessions')
      .insert({
        subject_id: subjectId,
        duration_minutes: durationMinutes,
        session_type: sessionType,
        completed_at: new Date().toISOString(),
      })
      .select('*, subject:subjects(*)')
      .single();
    if (error) throw error;
    setSessions((prev) => [data as StudySession, ...prev]);
    return data;
  };

  const deleteSession = async (id: string) => {
    const { error } = await supabase.from('study_sessions').delete().eq('id', id);
    if (error) throw error;
    setSessions((prev) => prev.filter((s) => s.id !== id));
  };

  return { sessions, loading, createSession, deleteSession, refetch: fetchSessions };
}
