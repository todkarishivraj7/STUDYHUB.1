import { Menu, Sun, Moon, Bell } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';

interface TopBarProps {
  title: string;
  subtitle?: string;
  onMenuClick: () => void;
}

export function TopBar({ title, subtitle, onMenuClick }: TopBarProps) {
  const { theme, toggleTheme, prefs } = useTheme();

  return (
    <header className="sticky top-0 z-20 border-b border-slate-200/60 dark:border-white/5 bg-white/70 dark:bg-[#0a0e27]/70 backdrop-blur-xl">
      <div className="flex items-center justify-between px-4 py-4 md:px-8">
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuClick}
            className="md:hidden flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div>
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white md:text-2xl">{title}</h2>
            {subtitle && <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5 hidden sm:block">{subtitle}</p>}
          </div>
        </div>

        <div className="flex items-center gap-2 md:gap-3">
          <button className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors">
            <Bell className="h-5 w-5" />
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-violet-500 ring-2 ring-white dark:ring-[#0a0e27]" />
          </button>
          <button
            onClick={toggleTheme}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
          >
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
          <div className="flex items-center gap-3 pl-2 md:pl-3">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{prefs?.student_name || 'Student'}</p>
              <p className="text-xs text-slate-400 dark:text-slate-500">Student</p>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 text-white font-semibold text-sm shadow-lg shadow-violet-500/25">
              {(prefs?.student_name || 'S').charAt(0).toUpperCase()}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
